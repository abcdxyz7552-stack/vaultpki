# VaultPKI — Patch Notes v1.0.1

## Summary of Bugs Found & Fixed

---

### Bug 1 — CRITICAL CRASH: SQLite INTEGER overflow on signing (signer_serial)
**Files:** `src/core/replay_guard.py`, `src/core/signing.py`  
**Symptom:** `Python int too large to convert to SQLite INTEGER` at the moment of signing any file.  
**Root cause:** X.509 serial numbers are 160-bit random integers. SQLite's `INTEGER` type is 64-bit signed. Inserting a typical X.509 serial directly into an `INTEGER` column raises a Python `OverflowError`.

**Fix in `replay_guard.py`:**
- Changed column `signer_serial INTEGER` → `signer_serial TEXT`
- `_init_database()` now performs **safe schema migration**: detects the old `INTEGER` column via `PRAGMA table_info`, renames the table, recreates with `TEXT`, copies all rows (casting old values to TEXT), then drops the old table. No data is lost.

**Fix in `signing.py`:**
- `register_nonce()` call now passes `str(signer_cert.serial_number)` instead of the raw integer.
- `signer_serial` in the `.sig` JSON metadata is also stored as a string.

---

### Bug 2 — CRITICAL CRASH: App fails to start on PySide6 6.x (Qt.AA_EnableHighDpiScaling)
**Files:** `src/main.py`  
**Symptom:** `AttributeError: type object 'Qt' has no attribute 'AA_EnableHighDpiScaling'` on launch.  
**Root cause:** `Qt.AA_EnableHighDpiScaling` and `Qt.AA_UseHighDpiPixmaps` were removed in Qt 6 (handled automatically). Calling `app.setAttribute()` with these raises `AttributeError`.

**Fix:** Wrapped both attribute accesses in `try/except AttributeError` — silently skipped on Qt 6, still applied on Qt 5 if ever needed.

---

### Bug 3 — VERIFICATION CRASH: Timezone-naive/aware datetime comparison
**Files:** `src/core/validation.py`, `src/core/pki.py`  
**Symptom:** `TypeError: can't compare offset-naive and offset-aware datetimes` during certificate validation (and creation on newer cryptography library versions).  
**Root cause:** `cryptography >= 42.x` changed `not_valid_before` / `not_valid_after` to return timezone-aware UTC datetimes. The code used `datetime.datetime.utcnow()` (naive). Comparing naive vs aware raises `TypeError`.

**Fix in `validation.py`:**
- `_verify_time_validity()` checks `not_before.tzinfo`. If aware, uses `datetime.datetime.now(datetime.timezone.utc)`; otherwise falls back to `utcnow()`.
- Uses `cert.not_valid_before_utc` / `not_valid_after_utc` where available (cryptography >= 42).

**Fix in `pki.py`:**
- Introduced `_utcnow()` helper returning `datetime.datetime.now(datetime.timezone.utc)`.
- All `CertificateBuilder` date fields use `_utcnow()`.

---

### Bug 4 — LOGIC BUG: Replay protection blocks legitimate re-verification
**Files:** `src/core/signing.py`  
**Symptom:** Verifying the same valid signature twice would (non-deterministically) raise a "Replay attack detected" error.  
**Root cause:** The original `verify_signature()` compared `nonce_info['timestamp']` with `sig_metadata['timestamp']`. Since `register_nonce()` stores the _current_ wall-clock time (not the signature timestamp), these are almost never equal — so every second verification was flagged as a replay.

**Fix:** Replay is now detected by checking whether the **file_hash** in the DB differs from the file_hash in the signature. Same nonce + same file hash = legitimate re-verification (allowed). Same nonce + different file hash = genuine replay (blocked).

---

### Bug 5 — DATA CONSISTENCY: CRL serial comparison fails after JSON round-trip
**Files:** `src/core/crl.py`  
**Root cause:** Serials were stored as Python `int` in the JSON CRL. After `json.load()` they become Python `int` again — this is fine. But Attack Lab parsed user input with `int()` which would fail on hex strings, and if someone compared `is_revoked(some_str_serial)` it would never match.

**Fix:** All serials normalized to `str` internally. `revoke_certificate()` and `is_revoked()` both accept `int` or `str`.

---

### Bug 6 — USABILITY: Dashboard "User Certs" count always showed 0
**Files:** `src/ui/pages/dashboard.py`  
**Root cause:** No code was counting enrolled certificates.  
**Fix:** Counts `*.pem` files in CWD excluding `ca_cert.pem`. Added a "Refresh Stats" button. Stats also refresh when returning to the dashboard via sidebar navigation.

---

### Bug 7 — USABILITY: Attack Lab serial input only accepted decimal integers
**Files:** `src/ui/pages/attack_lab.py`  
**Root cause:** `int(serial_str)` fails if user pastes a hex serial number.  
**Fix:** `_parse_serial()` helper tries decimal first, then `0x…` hex, then raw hex. Clear error message on failure.

---

### Bug 8 — USABILITY: Attack Lab MITM test crashed if CA not set up
**Files:** `src/ui/pages/attack_lab.py`  
**Fix:** Wrapped `load_ca()` in `try/except FileNotFoundError` with a helpful message.

---

## Files Changed

| File | Changes |
|------|---------|
| `src/core/replay_guard.py` | **Schema migration**, TEXT column, str conversion |
| `src/core/signing.py` | **Replay logic fix**, str serial, defensive checks |
| `src/core/validation.py` | **Timezone-aware datetime fix** |
| `src/core/pki.py` | Timezone-aware `_utcnow()` helper |
| `src/core/crl.py` | Consistent str serial normalization |
| `src/main.py` | **HiDPI attribute guard** |
| `src/ui/main_window.py` | HiDPI guard (belt-and-suspenders), dashboard refresh on nav |
| `src/ui/pages/dashboard.py` | Working cert count, refresh button |
| `src/ui/pages/attack_lab.py` | Hex serial parsing, MITM error handling, clearer output |

---

## Run Instructions

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Launch from the src directory (important: CWD determines where files are saved)
cd vaultpki/src
python app.py
```

**Important:** Always launch from `vaultpki/src/`. All data files (CA cert, CRL, nonce DB, .p12 files) are saved relative to the working directory.

---

## Manual Test Checklist

### A. CA Setup
- [ ] Identity & Certs → "Create CA" → success message, `ca_cert.pem` + `ca_key.pem` appear in `src/`
- [ ] Close and reopen: "Load Existing CA" → loads without error
- [ ] Dashboard shows **CA Status: Active**

### B. User Enrollment
- [ ] Enroll "Alice" with password `alice123` → save `alice.p12` + `alice.pem`
- [ ] Enroll "Bob" with password `bob123` → save `bob.p12` + `bob.pem`
- [ ] Dashboard → Refresh → User Certs count = 2

### C. Signing & Verification
- [ ] Sign / Verify → Load Alice's `alice.p12` (password `alice123`)
- [ ] Select a test file → Sign → `testfile.txt.sig` created
- [ ] Verify: select `testfile.txt` + `testfile.txt.sig` → **VALID**
- [ ] Verify again (same files) → **VALID** (no false replay error)
- [ ] Tamper `testfile.txt` (add a character), re-verify → **INVALID: file modified**
- [ ] Restore original file, verify → **VALID** again

### D. Revocation
- [ ] Note Alice's serial from the enrollment output
- [ ] Attack Lab → enter Alice's serial → "Revoke Certificate"
- [ ] Sign / Verify: verify Alice's signature → **INVALID: certificate revoked**

### E. Encryption & Decryption
- [ ] Encrypt / Decrypt → Load Bob's `bob.pem` as recipient cert
- [ ] Select file → Encrypt → `.vault` file created
- [ ] Load Bob's `bob.p12` as decryptor → Decrypt vault → success
- [ ] Load Alice's `alice.p12` as decryptor → Decrypt vault → **FAIL: decryption error**

### F. Replay Attack Simulation
- [ ] Attack Lab → Replay section → select the `.sig` file used in step C
- [ ] "Simulate Replay Attack" → **ATTACK BLOCKED** (nonce already in DB)

### G. MITM Test
- [ ] Attack Lab → "Test MITM Validation" → both tests pass (valid accepted, fake rejected)

### H. Logs
- [ ] Audit Logs → Refresh → shows CA status, revoked count, nonce count, files
