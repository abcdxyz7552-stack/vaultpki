# VaultPKI - Quick Start & Testing Guide

## 🚀 Installation

```bash
# Navigate to project directory
cd vaultpki

# Install dependencies
pip install -r requirements.txt

# Verify installation
python -c "import PySide6; import cryptography; print('✅ Dependencies installed')"
```

## 🎮 Running the Application

```bash
# From the vaultpki directory
python src/app.py
```

The cyberpunk-themed GUI will launch with the dashboard displayed.

---

## 📋 Demo Workflow: Complete PKI Scenario

This workflow demonstrates all major features in a realistic scenario where Alice and Bob exchange signed and encrypted documents.

### Step 1: Initialize Certificate Authority (2 minutes)

**Via GUI:**
1. Click **"Identity & Certificates"** in sidebar
2. Click **"Create CA"** button
3. Wait for success message: "Certificate Authority created successfully!"
4. Verify files created: `ca_cert.pem` and `ca_key.pem`

**Expected Output:**
```
✅ CA Created Successfully!
   Serial: 123456789...
   Subject: CN=VaultPKI Root CA,O=VaultPKI,...
   Valid: 2026-02-15 to 2036-02-15
   Files: ca_cert.pem, ca_key.pem
```

**Via Command Line (Alternative):**
```python
from pathlib import Path
from core.pki import PKIManager

pki = PKIManager()
ca_cert, ca_key = pki.create_ca()
print(f"✅ CA created with serial: {ca_cert.serial_number}")
```

---

### Step 2: Enroll Alice (2 minutes)

**Via GUI:**
1. In **"Identity & Certificates"** page
2. Enter Username: `Alice`
3. Enter Email: `alice@example.com` (optional)
4. Enter P12 Password: `alice123` (remember this!)
5. Click **"Enroll User"**
6. Save PKCS#12 file as: `Alice.p12`
7. Note: `Alice.pem` certificate also created

**Expected Output:**
```
✅ User Enrolled Successfully!
   Serial: 987654321...
   Subject: CN=Alice,O=VaultPKI Users,...
   Identity: Alice.p12
   Certificate: Alice.pem
```

---

### Step 3: Enroll Bob (2 minutes)

**Repeat Step 2 for Bob:**
- Username: `Bob`
- Email: `bob@example.com`
- P12 Password: `bob123`
- Save as: `Bob.p12` and `Bob.pem`

---

### Step 4: Alice Signs a Document (3 minutes)

**Preparation:**
Create a test file:
```bash
echo "This is a confidential memo from Alice to Bob." > memo.txt
```

**Via GUI:**
1. Navigate to **"Sign / Verify"** page
2. Click **"Load PKCS#12 Identity"**
   - Select `Alice.p12`
   - Enter password: `alice123`
   - Verify: "✅ Loaded: CN=Alice..."
3. Click **"Select File to Sign"**
   - Choose `memo.txt`
4. Click **"Sign File"** button
5. Success! `memo.txt.sig` created

**Expected Output:**
```
✍️ Signing file: memo.txt...
✅ Signature created successfully!
   Signature file: memo.txt.sig
   Algorithm: ECDSA-SHA256
   Timestamp: 2026-02-15T10:45:30.123456
   Nonce: a1b2c3d4e5f6...
```

**Signature File Contents (`memo.txt.sig`):**
```json
{
  "file_name": "memo.txt",
  "file_hash_b64": "base64-encoded-hash",
  "timestamp": "2026-02-15T10:45:30.123456",
  "nonce": "64-char-hex-nonce",
  "signer_cert_pem": "-----BEGIN CERTIFICATE-----\n...",
  "signer_serial": 987654321,
  "algorithm": "ECDSA-SHA256",
  "signature_b64": "base64-encoded-signature"
}
```

---

### Step 5: Bob Verifies Alice's Signature (2 minutes)

**Via GUI:**
1. Still in **"Sign / Verify"** page
2. Scroll to **"Verify Signature"** section
3. Click **"Select Signed File"**
   - Choose `memo.txt`
4. Click **"Select Signature File"**
   - Choose `memo.txt.sig`
5. Click **"Verify Signature"** button

**Expected Output:**
```
🔍 Verifying signature for: memo.txt...
✅ SIGNATURE VALID!
   ✓ Signature cryptographically valid
   ✓ File integrity verified
   ✓ Certificate trusted and valid
   ✓ Certificate not revoked
   ✓ No replay detected
```

**Success Dialog:** "Signature verification PASSED! All security checks successful."

---

### Step 6: Test File Tampering Detection (2 minutes)

**Modify the signed file:**
```bash
echo "TAMPERED DATA" >> memo.txt
```

**Via GUI:**
1. Click **"Verify Signature"** again (same files)

**Expected Output:**
```
❌ SIGNATURE INVALID!
   ✗ File integrity check failed - file has been modified
```

**Success!** The system detected tampering.

**Restore original file:**
```bash
echo "This is a confidential memo from Alice to Bob." > memo.txt
```

---

### Step 7: Test Replay Attack Prevention (3 minutes)

**Via GUI:**
1. Navigate to **"Attack Lab"** page
2. In **"Replay Attack Simulation"** section
3. Click **"Select Signature File"**
   - Choose `memo.txt.sig`
4. Click **"Simulate Replay Attack"**

**Expected Output:**
```
🔄 REPLAY ATTACK SIMULATION
   Attempting to reuse nonce: a1b2c3d4e5f6...
   ✅ ATTACK BLOCKED!
   The replay guard detected the reused nonce
   Verification would fail with replay error
```

**What happened:** The nonce database recognized that this nonce was already used during the original signature verification. This prevents an attacker from replaying old signatures.

---

### Step 8: Test Certificate Revocation (4 minutes)

**Scenario:** Alice's credentials are compromised, so we revoke her certificate.

**Via GUI:**
1. Still in **"Attack Lab"** page
2. In **"Certificate Revocation"** section
3. Enter Serial Number: `[Alice's certificate serial from Step 2]`
   - You can find this in the output from Alice's enrollment
4. Click **"Revoke Certificate"**

**Expected Output:**
```
❌ Certificate REVOKED: 987654321
   This certificate is now invalid
   All signatures/encryption with this cert will fail verification
```

**Now test verification of Alice's signature:**
1. Go back to **"Sign / Verify"** page
2. Verify `memo.txt` with `memo.txt.sig` again

**Expected Output:**
```
❌ SIGNATURE INVALID!
   ✗ Signer certificate has been revoked
```

**Success!** The revoked certificate is detected and verification fails.

---

### Step 9: Alice Encrypts a File for Bob (3 minutes)

**Preparation:**
Create a confidential file:
```bash
echo "TOP SECRET: Q4 earnings data - DO NOT SHARE" > earnings.txt
```

**Via GUI:**
1. Navigate to **"Encrypt / Decrypt"** page
2. In **"Encrypt File"** section
3. Click **"Load Recipient Certificate"**
   - Choose `Bob.pem` (Bob's public certificate)
4. Click **"Select File to Encrypt"**
   - Choose `earnings.txt`
5. Click **"Encrypt File"** button

**Expected Output:**
```
🔐 Encrypting file: earnings.txt...
✅ File encrypted successfully!
   Vault file: earnings.txt.vault
   Algorithm: ECDH-AES256-GCM
   Recipient: [Bob's serial number]
```

**Vault File Created:** `earnings.txt.vault`

**Try opening the vault file:**
```bash
cat earnings.txt.vault
```
You'll see encrypted JSON - the data is completely protected!

---

### Step 10: Bob Decrypts Alice's Encrypted File (3 minutes)

**Via GUI:**
1. Still in **"Encrypt / Decrypt"** page
2. In **"Decrypt File"** section
3. Click **"Load PKCS#12 Identity"**
   - Choose `Bob.p12`
   - Enter password: `bob123`
4. Click **"Select Vault File"**
   - Choose `earnings.txt.vault`
5. Click **"Decrypt File"** button
6. Save decrypted file as: `earnings_decrypted.txt`

**Expected Output:**
```
🔓 Decrypting vault: earnings.txt.vault...
✅ File decrypted successfully!
   Output: earnings_decrypted.txt
   Size: 48 bytes
```

**Verify decryption:**
```bash
cat earnings_decrypted.txt
# Should show: TOP SECRET: Q4 earnings data - DO NOT SHARE
```

**Test wrong recipient:**
Try decrypting with Alice's key instead of Bob's - it will fail! Only Bob can decrypt files encrypted for him.

---

### Step 11: Test MITM Attack Prevention (2 minutes)

**Via GUI:**
1. Navigate to **"Attack Lab"** page
2. Scroll to **"MITM Attack Prevention"** section
3. Click **"Test MITM Validation"** button

**Expected Output:**
```
🛡️ MITM ATTACK PREVENTION TEST

Test 1: Valid Certificate from Our CA
   ✅ PASSED: Valid certificate accepted

Test 2: Certificate from Fake CA (MITM Attack)
   ✅ PASSED: MITM certificate rejected!
   The system detected the untrusted CA

🎯 MITM Protection Test Complete
   Certificate chain validation prevents MITM attacks
```

**What happened:** The system created a rogue CA certificate and attempted to validate a certificate signed by it. The validation correctly rejected the fake certificate because it wasn't signed by the trusted CA.

---

### Step 12: View Audit Logs (2 minutes)

**Via GUI:**
1. Navigate to **"Audit Logs"** page
2. Click **"Refresh Logs"** to see current status

**Expected Output:**
```
================================================================================
                     VaultPKI - System Audit Log
                  Generated: 2026-02-15 10:55:30
================================================================================

📊 SYSTEM STATUS
--------------------------------------------------------------------------------
✅ Certificate Authority: ACTIVE
   CA Cert: /path/to/ca_cert.pem

🔒 CERTIFICATE REVOCATION LIST
--------------------------------------------------------------------------------
Total Revoked Certificates: 1
Revoked Serials: 987654321

🔄 REPLAY PROTECTION (NONCE DATABASE)
--------------------------------------------------------------------------------
Total Nonces Stored: 2
Database: /path/to/nonce_db.sqlite

📁 CRYPTOGRAPHIC FILES
--------------------------------------------------------------------------------
Certificates: 3 file(s)
   • ca_cert.pem
   • Alice.pem
   • Bob.pem
PKCS#12 Identities: 2 file(s)
   • Alice.p12
   • Bob.p12
Signatures: 1 file(s)
   • memo.txt.sig
Encrypted Vaults: 1 file(s)
   • earnings.txt.vault

================================================================================
```

---

## 🧪 Advanced Testing Scenarios

### Scenario A: Large File Encryption

```bash
# Create 10MB test file
dd if=/dev/urandom of=large_file.bin bs=1M count=10

# Encrypt for Bob (use GUI)
# Measure time and verify decryption produces identical file
```

### Scenario B: Batch Signing

```bash
# Create multiple files
for i in {1..10}; do
    echo "Document $i" > doc_$i.txt
done

# Sign each file with Alice's identity (use GUI or script)
# Verify all signatures
```

### Scenario C: Certificate Rotation

```bash
# Revoke old certificate
# Enroll user again with new certificate
# Old signatures still verify (unless cert is revoked)
# New operations use new certificate
```

---

## 🐛 Troubleshooting

### Issue: "CA files not found"
**Solution:** Run Step 1 to create the CA first.

### Issue: "Failed to import PKCS#12: incorrect password"
**Solution:** Verify you're using the correct password you set during enrollment.

### Issue: "Signature verification failed"
**Solutions:**
- Ensure you selected the correct file and signature pair
- Check if certificate was revoked
- Verify file wasn't modified after signing

### Issue: "Decryption failed"
**Solutions:**
- Ensure you're using the recipient's private key (correct PKCS#12 file)
- Verify the vault file wasn't corrupted
- Check that the vault was encrypted for this recipient

---

## 📊 Performance Benchmarks

Expected performance on modern hardware:

| Operation | Time |
|-----------|------|
| CA Creation | < 1 second |
| User Enrollment | < 500ms |
| Sign 1MB file | < 100ms |
| Verify signature | < 50ms |
| Encrypt 1MB file | < 50ms |
| Decrypt 1MB file | < 50ms |

---

## ✅ Verification Checklist

After completing the demo workflow, verify:

- [ ] CA certificate and key exist
- [ ] Alice and Bob enrolled with PKCS#12 identities
- [ ] Signature created and verified successfully
- [ ] File tampering detected
- [ ] Replay attack blocked
- [ ] Revoked certificate rejected
- [ ] File encrypted and decrypted successfully
- [ ] MITM attack prevented
- [ ] Audit logs showing all operations

---

## 🎓 Learning Outcomes

By completing this workflow, you've demonstrated:

1. **PKI Fundamentals:** CA creation, certificate issuance, chain of trust
2. **Digital Signatures:** File signing, verification, non-repudiation
3. **Hybrid Encryption:** Public-key encryption with symmetric ciphers
4. **Security Features:** Replay protection, revocation, MITM prevention
5. **Practical Operations:** Key management, certificate lifecycle

---

## 🚀 Next Steps

**For Developers:**
- Integrate VaultPKI into your application via Python API
- Customize certificate fields and validity periods
- Implement automated key rotation
- Add logging hooks for SIEM integration

**For Security Researchers:**
- Test additional attack scenarios
- Benchmark performance with large datasets
- Analyze cryptographic implementations
- Contribute security enhancements

**For Students:**
- Study the source code in `src/core/` modules
- Experiment with different cryptographic parameters
- Read the SECURITY_REPORT.md for threat analysis
- Build additional features (e.g., OCSP support)

---

**Happy Hacking! 🔐**
