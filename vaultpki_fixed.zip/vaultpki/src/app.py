#!/usr/bin/env python3
"""
VaultPKI - Advanced Cryptographic Toolkit
Entry point for the application
"""

import sys
from pathlib import Path

# Add src directory to Python path
sys.path.insert(0, str(Path(__file__).parent))

if __name__ == "__main__":
    from main import main
    main()
