"""
VaultPKI - Certificate Revocation List (CRL)
Manages revoked certificate tracking

FIXED:
- Revoked serials stored as strings in JSON (X.509 serials are large ints;
  JSON round-trip loses nothing for ints, but we normalize to str for
  consistent is_revoked() lookup regardless of int vs str caller).
- is_revoked() accepts both int and str serial numbers.
"""

import json
from pathlib import Path
from datetime import datetime


class CRLManager:
    """Manages Certificate Revocation List"""

    def __init__(self, crl_path: Path = None):
        self.crl_path = crl_path or Path.cwd() / "crl.json"
        self.revoked_serials = set()  # stored as strings internally
        self._load_crl()

    def _load_crl(self):
        """Load CRL from disk"""
        if self.crl_path.exists():
            try:
                with open(self.crl_path, 'r') as f:
                    data = json.load(f)
                # Normalize all serials to str for consistent comparison
                self.revoked_serials = set(
                    str(s) for s in data.get('revoked_serials', [])
                )
            except Exception as e:
                print(f"Warning: Failed to load CRL: {e}")
                self.revoked_serials = set()
        else:
            self.revoked_serials = set()

    def _save_crl(self):
        """Save CRL to disk"""
        data = {
            'revoked_serials': list(self.revoked_serials),
            'last_updated': datetime.utcnow().isoformat()
        }
        with open(self.crl_path, 'w') as f:
            json.dump(data, f, indent=2)

    def revoke_certificate(self, serial_number) -> bool:
        """
        Revoke a certificate by serial number (int or str accepted).

        Returns:
            bool: True if newly revoked, False if already revoked
        """
        key = str(serial_number)
        if key in self.revoked_serials:
            return False
        self.revoked_serials.add(key)
        self._save_crl()
        return True

    def is_revoked(self, serial_number) -> bool:
        """
        Check if a certificate is revoked. Accepts int or str.

        Returns:
            bool: True if revoked
        """
        return str(serial_number) in self.revoked_serials

    def unrevoke_certificate(self, serial_number) -> bool:
        """
        Remove a certificate from CRL (for testing purposes).

        Returns:
            bool: True if was revoked and now removed
        """
        key = str(serial_number)
        if key not in self.revoked_serials:
            return False
        self.revoked_serials.remove(key)
        self._save_crl()
        return True

    def get_revoked_count(self) -> int:
        """Get count of revoked certificates"""
        return len(self.revoked_serials)

    def get_all_revoked(self) -> list:
        """Get list of all revoked serial numbers (as strings)"""
        return list(self.revoked_serials)

    def clear_all(self):
        """Clear all revocations (for testing)"""
        self.revoked_serials = set()
        self._save_crl()
