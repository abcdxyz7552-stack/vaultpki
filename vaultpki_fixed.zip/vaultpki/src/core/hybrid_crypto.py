"""
VaultPKI - Hybrid Encryption System
Combines AES-256-GCM with ECDH key exchange for secure file encryption
"""

import json
import base64
import secrets
from pathlib import Path
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.backends import default_backend


class HybridCrypto:
    """Implements hybrid encryption using ECDH + AES-256-GCM"""
    
    @staticmethod
    def encrypt_file(file_path: Path,
                     recipient_cert: x509.Certificate,
                     output_path: Path = None) -> dict:
        """
        Encrypt file using hybrid encryption
        
        Process:
        1. Generate random AES-256 key
        2. Encrypt file with AES-256-GCM
        3. Generate ephemeral ECDH keypair
        4. Perform ECDH with recipient's public key
        5. Derive wrapping key using HKDF
        6. Wrap AES key with AES-GCM using wrapping key
        7. Package everything in JSON vault
        
        Args:
            file_path: Path to file to encrypt
            recipient_cert: Recipient's certificate (contains public key)
            output_path: Optional output path for vault file
            
        Returns:
            dict: Vault metadata
        """
        # Read plaintext file
        with open(file_path, 'rb') as f:
            plaintext = f.read()
        
        # Step 1: Generate random AES-256 key for file encryption
        file_key = AESGCM.generate_key(bit_length=256)
        
        # Step 2: Encrypt file with AES-256-GCM
        aesgcm = AESGCM(file_key)
        iv = secrets.token_bytes(12)  # 96-bit IV for GCM
        ciphertext = aesgcm.encrypt(iv, plaintext, None)
        
        # Step 3: Generate ephemeral ECDH keypair
        ephemeral_private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
        ephemeral_public_key = ephemeral_private_key.public_key()
        
        # Step 4: Perform ECDH with recipient's public key
        recipient_public_key = recipient_cert.public_key()
        shared_secret = ephemeral_private_key.exchange(
            ec.ECDH(), 
            recipient_public_key
        )
        
        # Step 5: Derive wrapping key from shared secret using HKDF
        salt = secrets.token_bytes(16)
        wrapping_key = HKDF(
            algorithm=hashes.SHA256(),
            length=32,  # 256 bits
            salt=salt,
            info=b'VaultPKI-KeyWrap',
            backend=default_backend()
        ).derive(shared_secret)
        
        # Step 6: Wrap (encrypt) the file encryption key
        wrap_aesgcm = AESGCM(wrapping_key)
        wrap_iv = secrets.token_bytes(12)
        wrapped_key = wrap_aesgcm.encrypt(wrap_iv, file_key, None)
        
        # Step 7: Build vault container
        vault = {
            'version': '1.0',
            'algorithm': 'ECDH-AES256-GCM',
            'file_name': file_path.name,
            'ciphertext': base64.b64encode(ciphertext).decode(),
            'iv': base64.b64encode(iv).decode(),
            'recipient_serial': recipient_cert.serial_number,
            'recipient_cert_pem': recipient_cert.public_bytes(serialization.Encoding.PEM).decode(),
            'eph_pub_pem': ephemeral_public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            ).decode(),
            'salt': base64.b64encode(salt).decode(),
            'wrap_iv': base64.b64encode(wrap_iv).decode(),
            'wrapped_key': base64.b64encode(wrapped_key).decode(),
        }
        
        # Save vault file
        if output_path is None:
            output_path = file_path.with_suffix(file_path.suffix + '.vault')
        
        with open(output_path, 'w') as f:
            json.dump(vault, f, indent=2)
        
        return vault
    
    @staticmethod
    def decrypt_file(vault_path: Path,
                     recipient_private_key: ec.EllipticCurvePrivateKey,
                     output_path: Path = None) -> bytes:
        """
        Decrypt file from vault using recipient's private key
        
        Process:
        1. Load vault
        2. Perform ECDH with ephemeral public key
        3. Derive wrapping key using HKDF
        4. Unwrap (decrypt) AES key
        5. Decrypt file ciphertext
        
        Args:
            vault_path: Path to .vault file
            recipient_private_key: Recipient's private key
            output_path: Optional output path for decrypted file
            
        Returns:
            bytes: Decrypted plaintext
        """
        # Load vault
        with open(vault_path, 'r') as f:
            vault = json.load(f)
        
        # Extract components
        ciphertext = base64.b64decode(vault['ciphertext'])
        iv = base64.b64decode(vault['iv'])
        eph_pub_pem = vault['eph_pub_pem'].encode()
        salt = base64.b64decode(vault['salt'])
        wrap_iv = base64.b64decode(vault['wrap_iv'])
        wrapped_key = base64.b64decode(vault['wrapped_key'])
        
        # Load ephemeral public key
        ephemeral_public_key = serialization.load_pem_public_key(
            eph_pub_pem,
            backend=default_backend()
        )
        
        # Perform ECDH with ephemeral public key
        shared_secret = recipient_private_key.exchange(
            ec.ECDH(),
            ephemeral_public_key
        )
        
        # Derive wrapping key (same process as encryption)
        wrapping_key = HKDF(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            info=b'VaultPKI-KeyWrap',
            backend=default_backend()
        ).derive(shared_secret)
        
        # Unwrap (decrypt) the file encryption key
        wrap_aesgcm = AESGCM(wrapping_key)
        file_key = wrap_aesgcm.decrypt(wrap_iv, wrapped_key, None)
        
        # Decrypt the file ciphertext
        aesgcm = AESGCM(file_key)
        plaintext = aesgcm.decrypt(iv, ciphertext, None)
        
        # Save decrypted file
        if output_path:
            with open(output_path, 'wb') as f:
                f.write(plaintext)
        
        return plaintext
    
    @staticmethod
    def get_vault_info(vault_path: Path) -> dict:
        """
        Extract information from vault file without decryption
        
        Args:
            vault_path: Path to .vault file
            
        Returns:
            dict: Vault metadata
        """
        with open(vault_path, 'r') as f:
            vault = json.load(f)
        
        return {
            'version': vault.get('version'),
            'algorithm': vault.get('algorithm'),
            'file_name': vault.get('file_name'),
            'recipient_serial': vault.get('recipient_serial'),
            'encrypted_size': len(base64.b64decode(vault.get('ciphertext', ''))),
        }
