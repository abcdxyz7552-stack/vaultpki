"""
VaultPKI - PKCS#12 Keystore Management
Handles secure password-protected identity export and import
"""

from pathlib import Path
from cryptography import x509
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.serialization import pkcs12


class KeystoreManager:
    """Manages PKCS#12 keystore operations for secure identity storage"""
    
    @staticmethod
    def export_p12(certificate: x509.Certificate, 
                   private_key: ec.EllipticCurvePrivateKey,
                   password: str,
                   output_path: Path,
                   friendly_name: str = None) -> bool:
        """
        Export identity (certificate + private key) as PKCS#12 file
        
        Args:
            certificate: X.509 certificate
            private_key: ECC private key
            password: Protection password
            output_path: Path to save .p12 file
            friendly_name: Optional friendly name for the identity
            
        Returns:
            bool: True if successful
        """
        try:
            # Create PKCS#12 bundle
            p12_data = pkcs12.serialize_key_and_certificates(
                name=friendly_name.encode('utf-8') if friendly_name else None,
                key=private_key,
                cert=certificate,
                cas=None,  # Could include CA cert chain here
                encryption_algorithm=serialization.BestAvailableEncryption(password.encode('utf-8'))
            )
            
            # Write to file
            with open(output_path, 'wb') as f:
                f.write(p12_data)
            
            return True
        except Exception as e:
            raise RuntimeError(f"Failed to export PKCS#12: {e}")
    
    @staticmethod
    def import_p12(p12_path: Path, 
                   password: str) -> tuple:
        """
        Import identity from PKCS#12 file
        
        Args:
            p12_path: Path to .p12 file
            password: Protection password
            
        Returns:
            tuple: (private_key, certificate, additional_certificates)
        """
        try:
            with open(p12_path, 'rb') as f:
                p12_data = f.read()
            
            # Load PKCS#12 bundle
            private_key, certificate, additional_certs = pkcs12.load_key_and_certificates(
                p12_data,
                password.encode('utf-8'),
                backend=default_backend()
            )
            
            return private_key, certificate, additional_certs
        except Exception as e:
            raise RuntimeError(f"Failed to import PKCS#12: {e}")
    
    @staticmethod
    def export_certificate_only(certificate: x509.Certificate, 
                                 output_path: Path) -> bool:
        """
        Export only the certificate (public key) as PEM file
        
        Args:
            certificate: X.509 certificate
            output_path: Path to save .pem file
            
        Returns:
            bool: True if successful
        """
        try:
            with open(output_path, 'wb') as f:
                f.write(certificate.public_bytes(serialization.Encoding.PEM))
            return True
        except Exception as e:
            raise RuntimeError(f"Failed to export certificate: {e}")
    
    @staticmethod
    def import_certificate_only(pem_path: Path) -> x509.Certificate:
        """
        Import certificate from PEM file
        
        Args:
            pem_path: Path to .pem file
            
        Returns:
            x509.Certificate: The loaded certificate
        """
        try:
            with open(pem_path, 'rb') as f:
                return x509.load_pem_x509_certificate(f.read(), default_backend())
        except Exception as e:
            raise RuntimeError(f"Failed to import certificate: {e}")
    
    @staticmethod
    def verify_password(p12_path: Path, password: str) -> bool:
        """
        Verify if password is correct for PKCS#12 file
        
        Args:
            p12_path: Path to .p12 file
            password: Password to test
            
        Returns:
            bool: True if password is correct
        """
        try:
            KeystoreManager.import_p12(p12_path, password)
            return True
        except:
            return False
