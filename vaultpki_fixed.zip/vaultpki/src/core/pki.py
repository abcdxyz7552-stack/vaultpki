"""
VaultPKI - Certificate Authority and Certificate Management
Handles CA generation, user enrollment, and certificate operations

FIXED:
- datetime: use timezone-aware UTC datetimes (cryptography >= 42 deprecates utcnow())
- _is_ca_certificate: defensive try/except preserved
"""

import datetime
from pathlib import Path
from cryptography import x509
from cryptography.x509.oid import NameOID, ExtensionOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.backends import default_backend


def _utcnow():
    """Return current UTC time. Works with both old and new cryptography versions."""
    try:
        return datetime.datetime.now(datetime.timezone.utc)
    except Exception:
        return datetime.datetime.utcnow()


class PKIManager:
    """Manages Certificate Authority and certificate operations"""

    def __init__(self, base_dir: Path = None):
        self.base_dir = base_dir or Path.cwd()
        self.ca_cert_path = self.base_dir / "ca_cert.pem"
        self.ca_key_path = self.base_dir / "ca_key.pem"
        self.ca_cert = None
        self.ca_private_key = None

    def create_ca(self, common_name: str = "VaultPKI Root CA",
                  organization: str = "VaultPKI",
                  validity_days: int = 3650) -> tuple:
        """
        Generate a new Certificate Authority.

        Returns:
            tuple: (ca_certificate, ca_private_key)
        """
        # Generate ECC P-256 private key
        private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())

        now = _utcnow()

        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COUNTRY_NAME, "US"),
            x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, "California"),
            x509.NameAttribute(NameOID.LOCALITY_NAME, "San Francisco"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, organization),
            x509.NameAttribute(NameOID.COMMON_NAME, common_name),
        ])

        cert_builder = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(private_key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now)
            .not_valid_after(now + datetime.timedelta(days=validity_days))
            .add_extension(
                x509.BasicConstraints(ca=True, path_length=None),
                critical=True,
            )
            .add_extension(
                x509.KeyUsage(
                    digital_signature=True,
                    key_cert_sign=True,
                    crl_sign=True,
                    key_encipherment=False,
                    content_commitment=False,
                    data_encipherment=False,
                    key_agreement=False,
                    encipher_only=False,
                    decipher_only=False,
                ),
                critical=True,
            )
            .add_extension(
                x509.SubjectKeyIdentifier.from_public_key(private_key.public_key()),
                critical=False,
            )
        )

        certificate = cert_builder.sign(private_key, hashes.SHA256(), default_backend())

        self._save_ca(certificate, private_key)
        self.ca_cert = certificate
        self.ca_private_key = private_key

        return certificate, private_key

    def load_ca(self) -> tuple:
        """
        Load existing CA from disk.

        Returns:
            tuple: (ca_certificate, ca_private_key)
        """
        if not self.ca_cert_path.exists() or not self.ca_key_path.exists():
            raise FileNotFoundError("CA files not found. Create CA first.")

        with open(self.ca_cert_path, "rb") as f:
            self.ca_cert = x509.load_pem_x509_certificate(f.read(), default_backend())

        with open(self.ca_key_path, "rb") as f:
            self.ca_private_key = serialization.load_pem_private_key(
                f.read(),
                password=None,
                backend=default_backend()
            )

        return self.ca_cert, self.ca_private_key

    def _save_ca(self, certificate, private_key):
        """Save CA certificate and private key to disk"""
        with open(self.ca_cert_path, "wb") as f:
            f.write(certificate.public_bytes(serialization.Encoding.PEM))

        with open(self.ca_key_path, "wb") as f:
            f.write(private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption()
            ))

    def enroll_user(self, username: str, email: str = None,
                    validity_days: int = 365) -> tuple:
        """
        Enroll a new user by generating keypair and issuing certificate.

        Returns:
            tuple: (user_certificate, user_private_key)
        """
        if not self.ca_cert or not self.ca_private_key:
            try:
                self.load_ca()
            except FileNotFoundError:
                raise ValueError("CA not initialized. Create CA first.")

        user_private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())

        csr_subject = [
            x509.NameAttribute(NameOID.COUNTRY_NAME, "US"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "VaultPKI Users"),
            x509.NameAttribute(NameOID.COMMON_NAME, username),
        ]

        if email:
            csr_subject.append(x509.NameAttribute(NameOID.EMAIL_ADDRESS, email))

        csr = (
            x509.CertificateSigningRequestBuilder()
            .subject_name(x509.Name(csr_subject))
            .sign(user_private_key, hashes.SHA256(), default_backend())
        )

        now = _utcnow()

        user_cert = (
            x509.CertificateBuilder()
            .subject_name(csr.subject)
            .issuer_name(self.ca_cert.subject)
            .public_key(csr.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now)
            .not_valid_after(now + datetime.timedelta(days=validity_days))
            .add_extension(
                x509.BasicConstraints(ca=False, path_length=None),
                critical=True,
            )
            .add_extension(
                x509.KeyUsage(
                    digital_signature=True,
                    key_encipherment=True,
                    content_commitment=False,
                    data_encipherment=False,
                    key_agreement=True,
                    key_cert_sign=False,
                    crl_sign=False,
                    encipher_only=False,
                    decipher_only=False,
                ),
                critical=True,
            )
            .add_extension(
                x509.SubjectKeyIdentifier.from_public_key(user_private_key.public_key()),
                critical=False,
            )
            .add_extension(
                x509.AuthorityKeyIdentifier.from_issuer_public_key(
                    self.ca_private_key.public_key()
                ),
                critical=False,
            )
            .sign(self.ca_private_key, hashes.SHA256(), default_backend())
        )

        return user_cert, user_private_key

    def get_certificate_info(self, cert: x509.Certificate) -> dict:
        """Extract readable information from certificate"""
        not_before = cert.not_valid_before_utc if hasattr(cert, 'not_valid_before_utc') \
            else cert.not_valid_before
        not_after = cert.not_valid_after_utc if hasattr(cert, 'not_valid_after_utc') \
            else cert.not_valid_after
        return {
            "serial": cert.serial_number,
            "subject": cert.subject.rfc4514_string(),
            "issuer": cert.issuer.rfc4514_string(),
            "not_before": not_before,
            "not_after": not_after,
            "is_ca": self._is_ca_certificate(cert),
        }

    def _is_ca_certificate(self, cert: x509.Certificate) -> bool:
        """Check if certificate is a CA certificate"""
        try:
            basic_constraints = cert.extensions.get_extension_for_oid(
                ExtensionOID.BASIC_CONSTRAINTS
            ).value
            return basic_constraints.ca
        except x509.ExtensionNotFound:
            return False

    def export_certificate_pem(self, cert: x509.Certificate) -> bytes:
        """Export certificate as PEM bytes"""
        return cert.public_bytes(serialization.Encoding.PEM)

    def import_certificate_pem(self, pem_data: bytes) -> x509.Certificate:
        """Import certificate from PEM bytes"""
        return x509.load_pem_x509_certificate(pem_data, default_backend())
