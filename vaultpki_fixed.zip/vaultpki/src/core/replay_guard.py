"""
VaultPKI - Replay Attack Prevention
Uses SQLite database to track used nonces

FIXED:
- signer_serial stored as TEXT (was INTEGER -- crashed on large X.509 serials)
- Safe schema migration from old INTEGER schema to new TEXT schema
"""

import sqlite3
from pathlib import Path
from datetime import datetime, timedelta


class ReplayGuard:
    """Prevents replay attacks using nonce tracking"""

    def __init__(self, db_path: Path = None):
        self.db_path = db_path or Path.cwd() / "nonce_db.sqlite"
        self._init_database()

    def _init_database(self):
        """Initialize SQLite database, create table, and migrate if needed."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Check if the table already exists
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='nonces'"
        )
        table_exists = cursor.fetchone() is not None

        if table_exists:
            # Inspect current schema
            cursor.execute("PRAGMA table_info(nonces)")
            columns = {row[1]: row[2] for row in cursor.fetchall()}  # name -> type
            serial_type = columns.get("signer_serial", "")

            if serial_type.upper() == "INTEGER":
                # Migrate: rename old table, create new, copy data, drop old
                cursor.execute("ALTER TABLE nonces RENAME TO nonces_old")
                cursor.execute("""
                    CREATE TABLE nonces (
                        nonce TEXT PRIMARY KEY,
                        timestamp TEXT NOT NULL,
                        file_hash TEXT,
                        signer_serial TEXT
                    )
                """)
                cursor.execute("""
                    INSERT INTO nonces (nonce, timestamp, file_hash, signer_serial)
                    SELECT nonce, timestamp, file_hash, CAST(signer_serial AS TEXT)
                    FROM nonces_old
                """)
                cursor.execute("DROP TABLE nonces_old")
        else:
            cursor.execute("""
                CREATE TABLE nonces (
                    nonce TEXT PRIMARY KEY,
                    timestamp TEXT NOT NULL,
                    file_hash TEXT,
                    signer_serial TEXT
                )
            """)

        conn.commit()
        conn.close()

    def register_nonce(self, nonce: str, file_hash: str = None,
                       signer_serial=None) -> bool:
        """
        Register a nonce as used.
        signer_serial is always stored as TEXT to handle large X.509 serial numbers.
        Returns True if newly registered, False if duplicate.
        """
        serial_str = str(signer_serial) if signer_serial is not None else None
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO nonces (nonce, timestamp, file_hash, signer_serial)
                VALUES (?, ?, ?, ?)
            """, (nonce, datetime.utcnow().isoformat(), file_hash, serial_str))
            conn.commit()
            conn.close()
            return True
        except sqlite3.IntegrityError:
            try:
                conn.close()
            except Exception:
                pass
            return False

    def is_nonce_used(self, nonce: str) -> bool:
        """Check if nonce has been used before."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM nonces WHERE nonce = ?", (nonce,))
        result = cursor.fetchone()
        conn.close()
        return result is not None

    def cleanup_old_nonces(self, days_old: int = 30) -> int:
        """Remove nonces older than specified days. Returns count deleted."""
        cutoff_date = (datetime.utcnow() - timedelta(days=days_old)).isoformat()
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM nonces WHERE timestamp < ?", (cutoff_date,))
        deleted_count = cursor.rowcount
        conn.commit()
        conn.close()
        return deleted_count

    def get_nonce_count(self) -> int:
        """Get total number of stored nonces"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM nonces")
        count = cursor.fetchone()[0]
        conn.close()
        return count

    def get_nonce_info(self, nonce: str) -> dict:
        """Get information about a specific nonce. Returns None if not found."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT nonce, timestamp, file_hash, signer_serial
            FROM nonces WHERE nonce = ?
        """, (nonce,))
        result = cursor.fetchone()
        conn.close()
        if result:
            return {
                'nonce': result[0],
                'timestamp': result[1],
                'file_hash': result[2],
                'signer_serial': result[3]
            }
        return None
