"""
VaultPKI - Digital Signature Operations
Handles file signing and verification with complete metadata tracking

FIXED:
- serial_number converted to str() before passing to replay_guard (avoids SQLite overflow)
- Replay check: nonce registered at sign-time; verify does NOT re-register.
  Re-verifying a legitimate signature is explicitly allowed.
  True replay attack: nonce in DB but file_hash differs from stored hash.
- Output .sig file saved alongside original file (path unchanged -- correct behaviour)
- Added defensive None/missing-field checks
"""

import json
import base64
import secrets
from pathlib import Path
from datetime import datetime
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.backends import default_backend
from cryptography.exceptions import InvalidSignature

from .validation import CertificateValidator
from .crl import CRLManager
from .replay_guard import ReplayGuard


class SignatureManager:
    """Manages digital signature creation and verification"""

    def __init__(self, ca_cert: x509.Certificate,
                 crl_manager: CRLManager,
                 replay_guard: ReplayGuard):
        self.validator = CertificateValidator(ca_cert)
        self.crl = crl_manager
        self.replay_guard = replay_guard

    def sign_file(self, file_path: Path,
                  signer_cert: x509.Certificate,
                  signer_key: ec.EllipticCurvePrivateKey,
                  output_path: Path = None) -> dict:
        """
        Create digital signature for a file.

        Returns:
            dict: Signature metadata
        """
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        # Read file and compute SHA-256 hash
        with open(file_path, 'rb') as f:
            file_data = f.read()

        digest = hashes.Hash(hashes.SHA256(), backend=default_backend())
        digest.update(file_data)
        file_hash = digest.finalize()

        # Generate unique nonce for replay protection
        nonce = secrets.token_hex(32)  # 256-bit nonce

        # Create message to sign: hash + timestamp + nonce
        timestamp = datetime.utcnow().isoformat()
        file_hash_b64 = base64.b64encode(file_hash).decode()
        message = f"{file_hash_b64}|{timestamp}|{nonce}".encode()

        # Sign the message using ECC private key
        signature = signer_key.sign(
            message,
            ec.ECDSA(hashes.SHA256())
        )

        # Build signature metadata
        sig_metadata = {
            'file_name': file_path.name,
            'file_hash_b64': file_hash_b64,
            'timestamp': timestamp,
            'nonce': nonce,
            'signer_cert_pem': signer_cert.public_bytes(serialization.Encoding.PEM).decode(),
            'signer_serial': str(signer_cert.serial_number),  # FIX: store as str
            'algorithm': 'ECDSA-SHA256',
            'signature_b64': base64.b64encode(signature).decode(),
        }

        # Register nonce to prevent replay — serial passed as str
        self.replay_guard.register_nonce(
            nonce,
            file_hash_b64,
            str(signer_cert.serial_number)  # FIX: str, not raw int
        )

        # Save signature file next to the original file
        if output_path is None:
            output_path = file_path.with_suffix(file_path.suffix + '.sig')

        with open(output_path, 'w') as f:
            json.dump(sig_metadata, f, indent=2)

        return sig_metadata

    def verify_signature(self, file_path: Path,
                         signature_path: Path) -> dict:
        """
        Verify digital signature of a file.

        Replay model:
        - The nonce is registered when a file is SIGNED.
        - Re-verifying the SAME signature (same nonce, same file_hash) is ALLOWED.
          This is normal: a verifier may check the same signed document many times.
        - A replay attack is detected when:
            * The nonce IS in the DB (was registered at sign time), AND
            * The stored file_hash DIFFERS from the hash in the signature being checked.
          This means someone has swapped the file content while reusing an old signature.

        Returns:
            dict: Verification results with detailed status
        """
        results = {
            'valid': True,
            'signature_valid': False,
            'integrity_valid': False,
            'certificate_valid': False,
            'not_revoked': False,
            'no_replay': False,
            'errors': [],
            'warnings': [],
            'details': {}
        }

        try:
            # Load signature metadata
            with open(signature_path, 'r') as f:
                sig_metadata = json.load(f)

            # Validate required fields
            required = ['file_hash_b64', 'timestamp', 'nonce',
                        'signer_cert_pem', 'signature_b64']
            missing = [k for k in required if k not in sig_metadata]
            if missing:
                results['valid'] = False
                results['errors'].append(f"Signature file missing fields: {missing}")
                return results

            results['details'] = {
                'signer_serial': sig_metadata.get('signer_serial'),
                'timestamp': sig_metadata.get('timestamp'),
                'algorithm': sig_metadata.get('algorithm', 'ECDSA-SHA256'),
                'file_name': sig_metadata.get('file_name'),
            }

            # Load signer's certificate
            try:
                signer_cert = x509.load_pem_x509_certificate(
                    sig_metadata['signer_cert_pem'].encode(),
                    default_backend()
                )
            except Exception as e:
                results['valid'] = False
                results['errors'].append(f"Cannot parse signer certificate: {e}")
                return results

            # ── Check 1: File integrity ──────────────────────────────────────
            if not file_path.exists():
                results['valid'] = False
                results['errors'].append(f"Signed file not found: {file_path}")
                return results

            with open(file_path, 'rb') as f:
                file_data = f.read()

            digest = hashes.Hash(hashes.SHA256(), backend=default_backend())
            digest.update(file_data)
            current_hash = digest.finalize()
            current_hash_b64 = base64.b64encode(current_hash).decode()

            if current_hash_b64 != sig_metadata['file_hash_b64']:
                results['valid'] = False
                results['errors'].append(
                    "File integrity check FAILED — file has been modified since signing"
                )
            else:
                results['integrity_valid'] = True

            # ── Check 2: Certificate chain validity ──────────────────────────
            cert_validation = self.validator.validate_certificate(signer_cert)
            if not cert_validation['valid']:
                results['valid'] = False
                results['errors'].extend(cert_validation['errors'])
            else:
                results['certificate_valid'] = True

            # ── Check 3: Certificate revocation ─────────────────────────────
            if self.crl.is_revoked(signer_cert.serial_number):
                results['valid'] = False
                results['errors'].append("Signer certificate has been REVOKED")
            else:
                results['not_revoked'] = True

            # ── Check 4: Replay protection ───────────────────────────────────
            # Correct model: nonce was registered at sign-time.
            # Re-verifying the same sig is fine. Replay = same nonce, different hash.
            nonce = sig_metadata['nonce']
            if self.replay_guard.is_nonce_used(nonce):
                nonce_info = self.replay_guard.get_nonce_info(nonce)
                stored_hash = nonce_info.get('file_hash') if nonce_info else None
                if stored_hash and stored_hash != sig_metadata['file_hash_b64']:
                    # Nonce reused with a DIFFERENT file hash — genuine replay
                    results['valid'] = False
                    results['errors'].append(
                        "REPLAY ATTACK detected — nonce reused with different file content"
                    )
                else:
                    # Same nonce AND same hash → legitimate re-verification
                    results['no_replay'] = True
            else:
                # Nonce not in DB at all.
                # This can happen if DB was wiped. Allow verification but warn.
                results['no_replay'] = True
                results['warnings'].append(
                    "Nonce not found in replay database (DB may have been cleared). "
                    "Signature is cryptographically valid."
                )

            # ── Check 5: Cryptographic signature ─────────────────────────────
            message = (
                f"{sig_metadata['file_hash_b64']}|"
                f"{sig_metadata['timestamp']}|"
                f"{nonce}"
            ).encode()
            signature_bytes = base64.b64decode(sig_metadata['signature_b64'])

            try:
                signer_cert.public_key().verify(
                    signature_bytes,
                    message,
                    ec.ECDSA(hashes.SHA256())
                )
                results['signature_valid'] = True
            except InvalidSignature:
                results['valid'] = False
                results['errors'].append(
                    "Cryptographic signature verification FAILED — signature is invalid"
                )

        except Exception as e:
            results['valid'] = False
            results['errors'].append(f"Verification error: {str(e)}")

        return results

    def get_signature_info(self, signature_path: Path) -> dict:
        """Extract information from signature file without verification."""
        with open(signature_path, 'r') as f:
            return json.load(f)
