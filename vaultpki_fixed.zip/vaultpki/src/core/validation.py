"""
VaultPKI - Certificate Chain Validation
Prevents MITM attacks through certificate chain verification

FIXED:
- datetime comparison: cryptography >= 42 returns timezone-aware datetimes.
  We now use timezone-aware UTC comparisons throughout.
"""

import datetime
from cryptography import x509
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.exceptions import InvalidSignature


class CertificateValidator:
    """Validates certificate chains and prevents MITM attacks"""

    def __init__(self, ca_certificate: x509.Certificate):
        self.ca_cert = ca_certificate

    def validate_certificate(self, cert: x509.Certificate) -> dict:
        """
        Perform complete certificate validation.

        Returns:
            dict: {'valid': bool, 'errors': list, 'warnings': list}
        """
        results = {
            'valid': True,
            'errors': [],
            'warnings': []
        }

        # Check 1: Verify certificate is signed by trusted CA
        if not self._verify_signature(cert):
            results['valid'] = False
            results['errors'].append("Certificate signature invalid — possible MITM attack")

        # Check 2: Verify issuer matches CA subject
        if not self._verify_issuer(cert):
            results['valid'] = False
            results['errors'].append("Certificate issuer does not match trusted CA")

        # Check 3: Verify time validity (handles both aware and naive datetimes)
        time_valid, time_msg = self._verify_time_validity(cert)
        if not time_valid:
            results['valid'] = False
            results['errors'].append(time_msg)

        # Check 4: Note if it's a CA certificate (informational)
        if self._is_ca_certificate(cert):
            results['warnings'].append("Certificate is marked as CA certificate")

        return results

    def _verify_signature(self, cert: x509.Certificate) -> bool:
        """Verify certificate is signed by the CA."""
        try:
            ca_public_key = self.ca_cert.public_key()
            ca_public_key.verify(
                cert.signature,
                cert.tbs_certificate_bytes,
                ec.ECDSA(cert.signature_hash_algorithm)
            )
            return True
        except InvalidSignature:
            return False
        except Exception as e:
            print(f"Signature verification error: {e}")
            return False

    def _verify_issuer(self, cert: x509.Certificate) -> bool:
        """Verify certificate issuer matches CA subject."""
        return cert.issuer == self.ca_cert.subject

    def _verify_time_validity(self, cert: x509.Certificate) -> tuple:
        """
        Verify certificate is within its validity period.
        Handles both timezone-aware and timezone-naive datetimes from the
        cryptography library (behaviour changed in cryptography >= 42.x).
        """
        # Determine if the cert dates are timezone-aware
        not_before = cert.not_valid_before_utc if hasattr(cert, 'not_valid_before_utc') \
            else cert.not_valid_before
        not_after = cert.not_valid_after_utc if hasattr(cert, 'not_valid_after_utc') \
            else cert.not_valid_after

        # Use timezone-aware now if the cert dates are aware, else naive
        if not_before.tzinfo is not None:
            now = datetime.datetime.now(datetime.timezone.utc)
        else:
            now = datetime.datetime.utcnow()

        if now < not_before:
            return False, f"Certificate not yet valid (valid from {not_before})"

        if now > not_after:
            return False, f"Certificate has expired (expired {not_after})"

        return True, "Certificate time validity OK"

    def _is_ca_certificate(self, cert: x509.Certificate) -> bool:
        """Check if certificate is a CA certificate."""
        try:
            basic_constraints = cert.extensions.get_extension_for_oid(
                x509.ExtensionOID.BASIC_CONSTRAINTS
            ).value
            return basic_constraints.ca
        except x509.ExtensionNotFound:
            return False

    def get_certificate_details(self, cert: x509.Certificate) -> dict:
        """Extract detailed information from certificate."""
        not_before = cert.not_valid_before_utc if hasattr(cert, 'not_valid_before_utc') \
            else cert.not_valid_before
        not_after = cert.not_valid_after_utc if hasattr(cert, 'not_valid_after_utc') \
            else cert.not_valid_after
        return {
            'serial_number': cert.serial_number,
            'subject': cert.subject.rfc4514_string(),
            'issuer': cert.issuer.rfc4514_string(),
            'not_before': not_before.isoformat(),
            'not_after': not_after.isoformat(),
            'is_ca': self._is_ca_certificate(cert),
            'signature_algorithm': (
                cert.signature_hash_algorithm.name
                if cert.signature_hash_algorithm else 'unknown'
            ),
        }

    def verify_chain(self, cert: x509.Certificate,
                     intermediate_certs: list = None) -> bool:
        """Verify complete certificate chain (single-level: CA -> User)."""
        validation = self.validate_certificate(cert)
        return validation['valid']
