"""
VaultPKI - Main Application Setup
Initializes the PySide6 application and main window

FIXED:
- Qt.AA_EnableHighDpiScaling / AA_UseHighDpiPixmaps removed in Qt 6 — guarded
  with try/except AttributeError so startup does not crash on any Qt6 version.
"""

import sys
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt

from ui.main_window import MainWindow


def main():
    """Initialize and run the VaultPKI application"""
    app = QApplication(sys.argv)
    app.setApplicationName("VaultPKI")
    app.setOrganizationName("VaultPKI")

    # High-DPI attributes were removed in Qt 6; guard gracefully.
    for attr_name in ("AA_EnableHighDpiScaling", "AA_UseHighDpiPixmaps"):
        try:
            attr = getattr(Qt, attr_name)
            app.setAttribute(attr, True)
        except AttributeError:
            pass  # Qt 6 handles HiDPI automatically

    window = MainWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
