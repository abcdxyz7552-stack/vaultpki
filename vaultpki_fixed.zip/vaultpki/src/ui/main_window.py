"""
VaultPKI - Main Window with Sidebar Navigation
Cyberpunk-themed dark UI with modern design

FIXED:
- Qt.AA_EnableHighDpiScaling and Qt.AA_UseHighDpiPixmaps removed in Qt6/PySide6 6.x.
  We now catch AttributeError so the app does not crash on any PySide6 version.
"""

from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                               QPushButton, QStackedWidget, QLabel, QFrame)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QPalette, QColor

from .pages.dashboard import DashboardPage
from .pages.identity import IdentityPage
from .pages.sign_verify import SignVerifyPage
from .pages.encrypt_decrypt import EncryptDecryptPage
from .pages.attack_lab import AttackLabPage
from .pages.logs import LogsPage


class MainWindow(QMainWindow):
    """Main application window with sidebar navigation"""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("VaultPKI — Advanced Cryptographic Toolkit")
        self.setGeometry(100, 100, 1400, 900)

        self._apply_theme()

        central = QWidget()
        self.setCentralWidget(central)

        main_layout = QHBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        sidebar = self._create_sidebar()
        main_layout.addWidget(sidebar)

        self.content_stack = QStackedWidget()
        self.content_stack.setStyleSheet("""
            QStackedWidget {
                background: #0a0e1a;
                border-left: 2px solid #00ff9d;
            }
        """)
        main_layout.addWidget(self.content_stack, 1)

        self._add_pages()

    def _apply_theme(self):
        """Apply cyberpunk dark theme"""
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor("#0a0e1a"))
        palette.setColor(QPalette.WindowText, QColor("#e0e0e0"))
        palette.setColor(QPalette.Base, QColor("#131820"))
        palette.setColor(QPalette.AlternateBase, QColor("#1a1f2e"))
        palette.setColor(QPalette.Text, QColor("#e0e0e0"))
        palette.setColor(QPalette.Button, QColor("#1a1f2e"))
        palette.setColor(QPalette.ButtonText, QColor("#e0e0e0"))
        self.setPalette(palette)

        self.setStyleSheet("""
            QMainWindow { background: #0a0e1a; }
            QLabel { color: #e0e0e0; }
            QPushButton {
                background: #1a1f2e;
                color: #e0e0e0;
                border: 1px solid #2a3f5f;
                border-radius: 6px;
                padding: 10px 20px;
                font-size: 14px;
                font-weight: 600;
            }
            QPushButton:hover {
                background: #2a3f5f;
                border: 1px solid #00ff9d;
            }
            QPushButton:pressed { background: #0d1117; }
            QLineEdit, QTextEdit {
                background: #131820;
                color: #e0e0e0;
                border: 1px solid #2a3f5f;
                border-radius: 4px;
                padding: 8px;
                font-size: 13px;
            }
            QLineEdit:focus, QTextEdit:focus { border: 1px solid #00ff9d; }
        """)

    def _create_sidebar(self):
        """Create navigation sidebar"""
        sidebar = QFrame()
        sidebar.setFixedWidth(280)
        sidebar.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #0a0e1a, stop:1 #131820);
                border-right: 2px solid #00ff9d;
            }
        """)

        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(20, 30, 20, 30)
        layout.setSpacing(15)

        title = QLabel("🔐 VaultPKI")
        title.setFont(QFont("Courier New", 24, QFont.Bold))
        title.setStyleSheet("""
            color: #00ff9d;
            padding: 20px 0;
            border-bottom: 2px solid #2a3f5f;
        """)
        layout.addWidget(title)

        subtitle = QLabel("Advanced Cryptographic Toolkit")
        subtitle.setFont(QFont("Arial", 10))
        subtitle.setStyleSheet("color: #7a8ba0; padding-bottom: 20px;")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        self.nav_buttons = []
        nav_items = [
            ("📊 Dashboard", 0),
            ("👤 Identity & Certs", 1),
            ("✍️  Sign / Verify", 2),
            ("🔐 Encrypt / Decrypt", 3),
            ("⚠️  Attack Lab", 4),
            ("📜 Audit Logs", 5),
        ]

        for text, page_index in nav_items:
            btn = QPushButton(text)
            btn.setFont(QFont("Arial", 12, QFont.Bold))
            btn.setStyleSheet("""
                QPushButton {
                    background: transparent;
                    color: #7a8ba0;
                    border: none;
                    border-left: 4px solid transparent;
                    border-radius: 0;
                    padding: 15px 20px;
                    text-align: left;
                    font-size: 13px;
                }
                QPushButton:hover {
                    background: rgba(0, 255, 157, 0.1);
                    color: #00ff9d;
                    border-left: 4px solid #00ff9d;
                }
                QPushButton:pressed { background: rgba(0, 255, 157, 0.2); }
            """)
            btn.clicked.connect(lambda checked, idx=page_index: self._switch_page(idx))
            layout.addWidget(btn)
            self.nav_buttons.append(btn)

        layout.addStretch()

        footer = QLabel("v1.0.1 | MIT License")
        footer.setFont(QFont("Arial", 9))
        footer.setStyleSheet("color: #4a5568; padding-top: 20px;")
        layout.addWidget(footer)

        return sidebar

    def _add_pages(self):
        """Add all pages to content stack"""
        self.dashboard = DashboardPage()
        self.identity = IdentityPage()
        self.sign_verify = SignVerifyPage()
        self.encrypt_decrypt = EncryptDecryptPage()
        self.attack_lab = AttackLabPage()
        self.logs = LogsPage()

        self.content_stack.addWidget(self.dashboard)
        self.content_stack.addWidget(self.identity)
        self.content_stack.addWidget(self.sign_verify)
        self.content_stack.addWidget(self.encrypt_decrypt)
        self.content_stack.addWidget(self.attack_lab)
        self.content_stack.addWidget(self.logs)

    def _switch_page(self, index):
        """Switch to selected page"""
        self.content_stack.setCurrentIndex(index)

        # Refresh dashboard stats when navigating to it
        if index == 0:
            try:
                self.dashboard.refresh_stats()
            except Exception:
                pass

        for i, btn in enumerate(self.nav_buttons):
            if i == index:
                btn.setStyleSheet("""
                    QPushButton {
                        background: rgba(0, 255, 157, 0.15);
                        color: #00ff9d;
                        border: none;
                        border-left: 4px solid #00ff9d;
                        border-radius: 0;
                        padding: 15px 20px;
                        text-align: left;
                        font-size: 13px;
                        font-weight: bold;
                    }
                """)
            else:
                btn.setStyleSheet("""
                    QPushButton {
                        background: transparent;
                        color: #7a8ba0;
                        border: none;
                        border-left: 4px solid transparent;
                        border-radius: 0;
                        padding: 15px 20px;
                        text-align: left;
                        font-size: 13px;
                    }
                    QPushButton:hover {
                        background: rgba(0, 255, 157, 0.1);
                        color: #00ff9d;
                        border-left: 4px solid #00ff9d;
                    }
                """)
