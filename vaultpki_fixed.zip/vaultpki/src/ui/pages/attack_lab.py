"""
VaultPKI - Attack Lab Page
Security testing and attack simulations

FIXED:
- revoke_certificate / check_revocation: serial number input now accepts both
  decimal integers AND hex strings (with/without 0x prefix) so users can
  paste the serial directly from the Identity page output.
- MITM test: wrapped in try/except with friendly error if CA not set up yet.
- Replay simulation: clearer output explaining the model.
"""

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                               QPushButton, QLineEdit, QTextEdit, QFileDialog,
                               QMessageBox, QGroupBox)
from PySide6.QtGui import QFont
from pathlib import Path

from core.pki import PKIManager
from core.crl import CRLManager
from core.replay_guard import ReplayGuard
from core.signing import SignatureManager


def _parse_serial(serial_str: str) -> int:
    """
    Parse a certificate serial number from user input.
    Accepts decimal, hex with '0x' prefix, or plain hex.
    Raises ValueError on bad input.
    """
    s = serial_str.strip()
    if not s:
        raise ValueError("Serial number is empty")
    try:
        if s.lower().startswith('0x'):
            return int(s, 16)
        return int(s)
    except ValueError:
        # Try treating as raw hex without prefix
        try:
            return int(s, 16)
        except ValueError:
            raise ValueError(
                f"Cannot parse '{s}' as a serial number. "
                "Enter a decimal integer or hex (0x...) value."
            )


class AttackLabPage(QWidget):
    """Security testing and attack simulations"""

    def __init__(self):
        super().__init__()
        self.pki = PKIManager()
        self.crl = CRLManager()
        self.replay_guard = ReplayGuard()
        self.replay_sig_file = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(40, 40, 40, 40)
        layout.setSpacing(20)

        title = QLabel("⚠️ Attack Lab")
        title.setFont(QFont("Arial", 28, QFont.Bold))
        title.setStyleSheet("color: #ff3864;")
        layout.addWidget(title)

        subtitle = QLabel("Security Testing & Attack Simulations")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setStyleSheet("color: #7a8ba0; padding-bottom: 20px;")
        layout.addWidget(subtitle)

        warning = QLabel("⚠️ This page simulates security attacks for testing purposes")
        warning.setStyleSheet("""
            color: #ffa500;
            background: rgba(255, 168, 0, 0.1);
            padding: 10px;
            border-left: 4px solid #ffa500;
            border-radius: 4px;
        """)
        layout.addWidget(warning)

        layout.addWidget(self._create_revocation_section())
        layout.addWidget(self._create_replay_section())
        layout.addWidget(self._create_mitm_section())

        self.output = QTextEdit()
        self.output.setReadOnly(True)
        self.output.setMaximumHeight(250)
        self.output.setStyleSheet("""
            QTextEdit {
                background: #0d1117;
                color: #ff3864;
                border: 1px solid #2a3f5f;
                border-radius: 6px;
                padding: 10px;
                font-family: 'Courier New';
                font-size: 11px;
            }
        """)
        layout.addWidget(self.output)
        layout.addStretch()

    def _create_revocation_section(self):
        group = QGroupBox("Certificate Revocation")
        group.setStyleSheet("""
            QGroupBox {
                color: #ff3864;
                border: 2px solid #2a3f5f;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 20px;
                font-size: 14px;
                font-weight: bold;
            }
        """)
        layout = QVBoxLayout()

        info = QLabel(
            "Revoke a certificate to test CRL validation.\n"
            "Enter the serial number shown in the Identity page output "
            "(decimal integer or 0x hex)."
        )
        info.setStyleSheet("color: #7a8ba0; padding: 10px;")
        info.setWordWrap(True)
        layout.addWidget(info)

        input_layout = QHBoxLayout()
        input_layout.addWidget(QLabel("Serial Number:"))
        self.revoke_serial_input = QLineEdit()
        self.revoke_serial_input.setPlaceholderText(
            "Decimal or 0x hex certificate serial number"
        )
        input_layout.addWidget(self.revoke_serial_input)
        layout.addLayout(input_layout)

        btn_layout = QHBoxLayout()
        revoke_btn = QPushButton("❌ Revoke Certificate")
        revoke_btn.clicked.connect(self.revoke_certificate)
        btn_layout.addWidget(revoke_btn)

        check_btn = QPushButton("🔍 Check Revocation Status")
        check_btn.clicked.connect(self.check_revocation)
        btn_layout.addWidget(check_btn)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)

        group.setLayout(layout)
        return group

    def _create_replay_section(self):
        group = QGroupBox("Replay Attack Simulation")
        group.setStyleSheet("""
            QGroupBox {
                color: #ffa500;
                border: 2px solid #2a3f5f;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 20px;
                font-size: 14px;
                font-weight: bold;
            }
        """)
        layout = QVBoxLayout()

        info = QLabel(
            "Simulates a replay attack by trying to re-register a nonce from an "
            "existing .sig file. If signing worked correctly, the nonce is already "
            "in the database and the attack will be blocked."
        )
        info.setStyleSheet("color: #7a8ba0; padding: 10px;")
        info.setWordWrap(True)
        layout.addWidget(info)

        file_layout = QHBoxLayout()
        self.replay_sig_label = QLabel("No signature file selected")
        self.replay_sig_label.setStyleSheet("color: #7a8ba0;")
        file_layout.addWidget(self.replay_sig_label)

        select_btn = QPushButton("📋 Select Signature File")
        select_btn.clicked.connect(self.select_signature_for_replay)
        file_layout.addWidget(select_btn)
        layout.addLayout(file_layout)

        btn_layout = QHBoxLayout()
        simulate_btn = QPushButton("🔄 Simulate Replay Attack")
        simulate_btn.clicked.connect(self.simulate_replay_attack)
        btn_layout.addWidget(simulate_btn)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)

        group.setLayout(layout)
        return group

    def _create_mitm_section(self):
        group = QGroupBox("MITM Attack Prevention")
        group.setStyleSheet("""
            QGroupBox {
                color: #9d00ff;
                border: 2px solid #2a3f5f;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 20px;
                font-size: 14px;
                font-weight: bold;
            }
        """)
        layout = QVBoxLayout()

        info = QLabel(
            "Tests certificate chain validation. A certificate from a fake/attacker CA "
            "must be rejected, while a valid certificate from our CA is accepted."
        )
        info.setStyleSheet("color: #7a8ba0; padding: 10px;")
        info.setWordWrap(True)
        layout.addWidget(info)

        btn_layout = QHBoxLayout()
        test_btn = QPushButton("🛡️ Test MITM Validation")
        test_btn.clicked.connect(self.test_mitm_validation)
        btn_layout.addWidget(test_btn)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)

        group.setLayout(layout)
        return group

    # ── Actions ──────────────────────────────────────────────────────────────

    def revoke_certificate(self):
        """Revoke a certificate by serial number"""
        serial_str = self.revoke_serial_input.text().strip()
        if not serial_str:
            QMessageBox.warning(self, "Input Required", "Please enter a certificate serial number")
            return
        try:
            serial = _parse_serial(serial_str)
        except ValueError as e:
            QMessageBox.critical(self, "Invalid Input", str(e))
            return

        try:
            if self.crl.revoke_certificate(serial):
                self.output.append(f"❌ Certificate REVOKED: {serial}")
                self.output.append("   This certificate is now invalid.")
                self.output.append(
                    "   Signature verification will reject it until unrevoked."
                )
                self.output.append("")
                QMessageBox.information(
                    self, "Revoked",
                    f"Certificate serial {serial} has been revoked!\n\n"
                    "It will no longer pass CRL validation."
                )
            else:
                self.output.append(f"⚠️ Certificate {serial} was already revoked")
                QMessageBox.information(self, "Already Revoked",
                                        "This certificate was already in the CRL.")
        except Exception as e:
            self.output.append(f"❌ Error: {str(e)}")
            QMessageBox.critical(self, "Error", f"Failed to revoke:\n{str(e)}")

    def check_revocation(self):
        """Check if a certificate is revoked"""
        serial_str = self.revoke_serial_input.text().strip()
        if not serial_str:
            QMessageBox.warning(self, "Input Required", "Please enter a serial number")
            return
        try:
            serial = _parse_serial(serial_str)
        except ValueError as e:
            QMessageBox.critical(self, "Invalid Input", str(e))
            return

        if self.crl.is_revoked(serial):
            self.output.append(f"❌ Certificate {serial} is REVOKED")
            QMessageBox.warning(self, "Revoked", f"Certificate serial {serial} is in the CRL.")
        else:
            self.output.append(f"✅ Certificate {serial} is NOT revoked")
            QMessageBox.information(self, "Valid", f"Certificate serial {serial} is not revoked.")

    def select_signature_for_replay(self):
        """Select signature file for replay attack test"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Signature File", "", "Signature Files (*.sig)"
        )
        if file_path:
            self.replay_sig_file = Path(file_path)
            self.replay_sig_label.setText(f"✅ {self.replay_sig_file.name}")
            self.replay_sig_label.setStyleSheet("color: #00ff9d;")

    def simulate_replay_attack(self):
        """Simulate a replay attack by trying to re-register an existing nonce"""
        if not self.replay_sig_file:
            QMessageBox.warning(self, "Missing File", "Please select a signature file first.")
            return

        try:
            import json
            with open(self.replay_sig_file, 'r') as f:
                sig_data = json.load(f)

            nonce = sig_data.get('nonce')
            if not nonce:
                QMessageBox.critical(self, "Error", "Signature file is missing the nonce field.")
                return

            self.output.append("🔄 REPLAY ATTACK SIMULATION")
            self.output.append(f"   Signature file : {self.replay_sig_file.name}")
            self.output.append(f"   Nonce (first 24): {nonce[:24]}...")
            self.output.append("")

            # Try to register the same nonce again
            if self.replay_guard.register_nonce(nonce):
                # Nonce was NOT in DB — signing never recorded it (unusual)
                self.output.append("   ⚠️  ATTACK WOULD SUCCEED (nonce not in database)")
                self.output.append("   This means the signing step did not record the nonce.")
                self.output.append("   Re-sign the file to populate the replay database.")
            else:
                # Nonce IS in DB — attack blocked
                self.output.append("   ✅ ATTACK BLOCKED!")
                self.output.append("   The replay guard detected the reused nonce.")
                self.output.append(
                    "   A verification attempt with a different file would be rejected."
                )
            self.output.append("")

            QMessageBox.information(
                self, "Replay Test Complete",
                "Replay attack simulation complete!\nCheck output for details."
            )
        except Exception as e:
            self.output.append(f"❌ Error: {str(e)}")
            QMessageBox.critical(self, "Error", f"Simulation failed:\n{str(e)}")

    def test_mitm_validation(self):
        """Test certificate chain validation (MITM prevention)"""
        try:
            from core.validation import CertificateValidator
            from cryptography.hazmat.primitives.asymmetric import ec
            from cryptography.hazmat.backends import default_backend
            from cryptography import x509
            from cryptography.x509.oid import NameOID
            from cryptography.hazmat.primitives import hashes
            import datetime

            self.output.append("🛡️ MITM ATTACK PREVENTION TEST")
            self.output.append("")

            # Load real CA — must exist
            try:
                ca_cert, ca_key = self.pki.load_ca()
            except FileNotFoundError:
                self.output.append("❌ CA not found. Create a CA first in Identity & Certs.")
                QMessageBox.warning(
                    self, "CA Required",
                    "Please create a Certificate Authority first\n"
                    "(Identity & Certs → Create CA)."
                )
                return

            validator = CertificateValidator(ca_cert)

            # ── Test 1: Valid certificate from our CA ─────────────────────────
            self.output.append("Test 1: Valid Certificate from Our CA")
            user_cert, _ = self.pki.enroll_user("MITMTestUser")
            result = validator.validate_certificate(user_cert)
            if result['valid']:
                self.output.append("   ✅ PASSED: Valid certificate accepted")
            else:
                self.output.append("   ❌ FAILED: Valid certificate rejected!")
                for err in result['errors']:
                    self.output.append(f"      {err}")

            # ── Test 2: Certificate from a fake CA ────────────────────────────
            self.output.append("")
            self.output.append("Test 2: Certificate from Fake CA (MITM Attack)")

            now = datetime.datetime.now(datetime.timezone.utc)
            fake_ca_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
            fake_ca_cert = (
                x509.CertificateBuilder()
                .subject_name(x509.Name([
                    x509.NameAttribute(NameOID.COMMON_NAME, "Fake CA (Attacker)")
                ]))
                .issuer_name(x509.Name([
                    x509.NameAttribute(NameOID.COMMON_NAME, "Fake CA (Attacker)")
                ]))
                .public_key(fake_ca_key.public_key())
                .serial_number(x509.random_serial_number())
                .not_valid_before(now)
                .not_valid_after(now + datetime.timedelta(days=365))
                .add_extension(
                    x509.BasicConstraints(ca=True, path_length=None), critical=True
                )
                .sign(fake_ca_key, hashes.SHA256(), default_backend())
            )

            fake_user_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
            fake_user_cert = (
                x509.CertificateBuilder()
                .subject_name(x509.Name([
                    x509.NameAttribute(NameOID.COMMON_NAME, "Fake User")
                ]))
                .issuer_name(fake_ca_cert.subject)
                .public_key(fake_user_key.public_key())
                .serial_number(x509.random_serial_number())
                .not_valid_before(now)
                .not_valid_after(now + datetime.timedelta(days=365))
                .add_extension(
                    x509.BasicConstraints(ca=False, path_length=None), critical=True
                )
                .sign(fake_ca_key, hashes.SHA256(), default_backend())
            )

            fake_result = validator.validate_certificate(fake_user_cert)
            if not fake_result['valid']:
                self.output.append("   ✅ PASSED: MITM certificate rejected!")
                self.output.append("   The system detected the untrusted CA correctly.")
            else:
                self.output.append("   ❌ FAILED: MITM certificate was accepted!")

            self.output.append("")
            self.output.append("🎯 MITM Protection Test Complete")
            self.output.append("")

            QMessageBox.information(
                self, "MITM Test Complete",
                "MITM prevention test complete!\n\nCheck output for details."
            )
        except Exception as e:
            self.output.append(f"❌ Error: {str(e)}")
            QMessageBox.critical(self, "Error", f"Test failed:\n{str(e)}")
