"""
VaultPKI - Dashboard Page
System status and quick stats

FIXED:
- cert_count: now counts .pem files in CWD (approximation of enrolled user certs)
  and excludes the CA cert itself.
- Stats refresh automatically when the page is shown.
"""

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                               QFrame, QGridLayout, QPushButton)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from pathlib import Path


class DashboardPage(QWidget):
    """Dashboard showing system status and statistics"""

    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(40, 40, 40, 40)
        layout.setSpacing(30)

        title = QLabel("📊 Dashboard")
        title.setFont(QFont("Arial", 28, QFont.Bold))
        title.setStyleSheet("color: #00ff9d; padding-bottom: 10px;")
        layout.addWidget(title)

        subtitle = QLabel("System Overview & Quick Stats")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setStyleSheet("color: #7a8ba0; padding-bottom: 20px;")
        layout.addWidget(subtitle)

        # Refresh button
        refresh_btn = QPushButton("🔄 Refresh Stats")
        refresh_btn.setMaximumWidth(160)
        refresh_btn.clicked.connect(self.refresh_stats)
        layout.addWidget(refresh_btn)

        # Stats grid
        stats_grid = QGridLayout()
        stats_grid.setSpacing(20)

        self.ca_status = self._create_stat_card("🏛️ CA Status", "Not Initialized", "#ff3864")
        self.cert_count = self._create_stat_card("📜 User Certs", "0", "#00ff9d")
        self.revoked_count = self._create_stat_card("⚠️ Revoked", "0", "#ffa500")
        self.nonce_count = self._create_stat_card("🔄 Nonces", "0", "#00d4ff")

        stats_grid.addWidget(self.ca_status, 0, 0)
        stats_grid.addWidget(self.cert_count, 0, 1)
        stats_grid.addWidget(self.revoked_count, 1, 0)
        stats_grid.addWidget(self.nonce_count, 1, 1)
        layout.addLayout(stats_grid)

        # Welcome message
        welcome = QFrame()
        welcome.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 rgba(0, 255, 157, 0.1), stop:1 rgba(0, 212, 255, 0.1));
                border-left: 4px solid #00ff9d;
                border-radius: 8px;
                padding: 20px;
            }
        """)
        welcome_layout = QVBoxLayout(welcome)

        welcome_title = QLabel("🚀 Welcome to VaultPKI")
        welcome_title.setFont(QFont("Arial", 16, QFont.Bold))
        welcome_title.setStyleSheet("color: #00ff9d;")
        welcome_layout.addWidget(welcome_title)

        welcome_text = QLabel(
            "VaultPKI is your complete cryptographic toolkit featuring:\n\n"
            "• Certificate Authority management\n"
            "• Digital signatures with replay protection\n"
            "• Hybrid encryption (ECDH + AES-256-GCM)\n"
            "• Certificate revocation and validation\n\n"
            "Get started by creating a CA in the Identity & Certificates page!"
        )
        welcome_text.setFont(QFont("Arial", 11))
        welcome_text.setStyleSheet("color: #e0e0e0; line-height: 1.6;")
        welcome_text.setWordWrap(True)
        welcome_layout.addWidget(welcome_text)

        layout.addWidget(welcome)
        layout.addStretch()

        self.refresh_stats()

    def _create_stat_card(self, title, value, color):
        """Create a stat display card"""
        card = QFrame()
        card.setStyleSheet("""
            QFrame {
                background: #131820;
                border: 1px solid #2a3f5f;
                border-radius: 10px;
                padding: 20px;
            }
        """)
        layout = QVBoxLayout(card)

        title_label = QLabel(title)
        title_label.setFont(QFont("Arial", 11))
        title_label.setStyleSheet("color: #7a8ba0;")
        layout.addWidget(title_label)

        value_label = QLabel(value)
        value_label.setFont(QFont("Courier New", 24, QFont.Bold))
        value_label.setStyleSheet(f"color: {color}; padding-top: 10px;")
        layout.addWidget(value_label)

        card.value_label = value_label
        card._color = color
        return card

    def refresh_stats(self):
        """Refresh dashboard statistics"""
        cwd = Path.cwd()

        # CA status
        ca_path = cwd / "ca_cert.pem"
        if ca_path.exists():
            self.ca_status.value_label.setText("Active")
            self.ca_status.value_label.setStyleSheet("color: #00ff9d; padding-top: 10px;")
        else:
            self.ca_status.value_label.setText("Not Initialized")
            self.ca_status.value_label.setStyleSheet("color: #ff3864; padding-top: 10px;")

        # User cert count: all .pem files except ca_cert.pem
        pem_files = [p for p in cwd.glob("*.pem") if p.name != "ca_cert.pem"]
        self.cert_count.value_label.setText(str(len(pem_files)))

        # Revoked certs
        try:
            from core.crl import CRLManager
            crl = CRLManager()
            self.revoked_count.value_label.setText(str(crl.get_revoked_count()))
        except Exception:
            self.revoked_count.value_label.setText("?")

        # Nonce count
        try:
            from core.replay_guard import ReplayGuard
            guard = ReplayGuard()
            self.nonce_count.value_label.setText(str(guard.get_nonce_count()))
        except Exception:
            self.nonce_count.value_label.setText("?")
