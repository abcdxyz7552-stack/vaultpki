"""
VaultPKI - Encrypt / Decrypt Page
Hybrid encryption operations
"""

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                               QPushButton, QLineEdit, QTextEdit, QFileDialog,
                               QMessageBox, QGroupBox, QInputDialog)
from PySide6.QtGui import QFont
from pathlib import Path

from core.hybrid_crypto import HybridCrypto
from core.keystore import KeystoreManager


class EncryptDecryptPage(QWidget):
    """Hybrid encryption and decryption"""
    
    def __init__(self):
        super().__init__()
        
        self.file_to_encrypt = None
        self.recipient_cert = None
        self.vault_file = None
        self.decryptor_key = None
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(40, 40, 40, 40)
        layout.setSpacing(20)
        
        # Page title
        title = QLabel("🔐 Encrypt / Decrypt")
        title.setFont(QFont("Arial", 28, QFont.Bold))
        title.setStyleSheet("color: #00ff9d;")
        layout.addWidget(title)
        
        subtitle = QLabel("Hybrid Encryption using ECDH + AES-256-GCM")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setStyleSheet("color: #7a8ba0; padding-bottom: 20px;")
        layout.addWidget(subtitle)
        
        # Encrypt section
        encrypt_group = self._create_encrypt_section()
        layout.addWidget(encrypt_group)
        
        # Decrypt section
        decrypt_group = self._create_decrypt_section()
        layout.addWidget(decrypt_group)
        
        # Output
        self.output = QTextEdit()
        self.output.setReadOnly(True)
        self.output.setMaximumHeight(250)
        self.output.setStyleSheet("""
            QTextEdit {
                background: #0d1117;
                color: #00ff9d;
                border: 1px solid #2a3f5f;
                border-radius: 6px;
                padding: 10px;
                font-family: 'Courier New';
                font-size: 11px;
            }
        """)
        layout.addWidget(self.output)
        
        layout.addStretch()
    
    def _create_encrypt_section(self):
        """Create encryption section"""
        group = QGroupBox("Encrypt File")
        group.setStyleSheet("""
            QGroupBox {
                color: #00ff9d;
                border: 2px solid #2a3f5f;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 20px;
                font-size: 14px;
                font-weight: bold;
            }
        """)
        
        layout = QVBoxLayout()
        
        # Load recipient certificate
        cert_layout = QHBoxLayout()
        self.recipient_label = QLabel("No recipient certificate loaded")
        self.recipient_label.setStyleSheet("color: #7a8ba0;")
        cert_layout.addWidget(self.recipient_label)
        
        load_cert_btn = QPushButton("📜 Load Recipient Certificate")
        load_cert_btn.clicked.connect(self.load_recipient_cert)
        cert_layout.addWidget(load_cert_btn)
        
        layout.addLayout(cert_layout)
        
        # Select file
        file_layout = QHBoxLayout()
        self.file_encrypt_label = QLabel("No file selected")
        self.file_encrypt_label.setStyleSheet("color: #7a8ba0;")
        file_layout.addWidget(self.file_encrypt_label)
        
        select_file_btn = QPushButton("📄 Select File to Encrypt")
        select_file_btn.clicked.connect(self.select_file_to_encrypt)
        file_layout.addWidget(select_file_btn)
        
        layout.addLayout(file_layout)
        
        # Encrypt button
        encrypt_btn = QPushButton("🔐 Encrypt File")
        encrypt_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #00ff9d, stop:1 #00d4ff);
                color: #0a0e1a;
                font-weight: bold;
                padding: 12px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #00d4ff, stop:1 #00ff9d);
            }
        """)
        encrypt_btn.clicked.connect(self.encrypt_file)
        layout.addWidget(encrypt_btn)
        
        group.setLayout(layout)
        return group
    
    def _create_decrypt_section(self):
        """Create decryption section"""
        group = QGroupBox("Decrypt File")
        group.setStyleSheet("""
            QGroupBox {
                color: #00d4ff;
                border: 2px solid #2a3f5f;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 20px;
                font-size: 14px;
                font-weight: bold;
            }
        """)
        
        layout = QVBoxLayout()
        
        # Load decryptor identity
        identity_layout = QHBoxLayout()
        self.decryptor_label = QLabel("No decryptor identity loaded")
        self.decryptor_label.setStyleSheet("color: #7a8ba0;")
        identity_layout.addWidget(self.decryptor_label)
        
        load_identity_btn = QPushButton("📂 Load PKCS#12 Identity")
        load_identity_btn.clicked.connect(self.load_decryptor_identity)
        identity_layout.addWidget(load_identity_btn)
        
        layout.addLayout(identity_layout)
        
        # Select vault
        vault_layout = QHBoxLayout()
        self.vault_label = QLabel("No vault selected")
        self.vault_label.setStyleSheet("color: #7a8ba0;")
        vault_layout.addWidget(self.vault_label)
        
        select_vault_btn = QPushButton("🗄️ Select Vault File")
        select_vault_btn.clicked.connect(self.select_vault_file)
        vault_layout.addWidget(select_vault_btn)
        
        layout.addLayout(vault_layout)
        
        # Decrypt button
        decrypt_btn = QPushButton("🔓 Decrypt File")
        decrypt_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #00d4ff, stop:1 #9d00ff);
                color: #0a0e1a;
                font-weight: bold;
                padding: 12px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #9d00ff, stop:1 #00d4ff);
            }
        """)
        decrypt_btn.clicked.connect(self.decrypt_file)
        layout.addWidget(decrypt_btn)
        
        group.setLayout(layout)
        return group
    
    def load_recipient_cert(self):
        """Load recipient's public key certificate"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load Recipient Certificate", "", "PEM Certificates (*.pem)"
        )
        
        if file_path:
            try:
                self.recipient_cert = KeystoreManager.import_certificate_only(Path(file_path))
                subject = self.recipient_cert.subject.rfc4514_string()
                self.recipient_label.setText(f"✅ {subject[:50]}...")
                self.recipient_label.setStyleSheet("color: #00ff9d;")
                self.output.append(f"✅ Recipient certificate loaded: {subject}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to load certificate:\n{str(e)}")
    
    def select_file_to_encrypt(self):
        """Select file to encrypt"""
        file_path, _ = QFileDialog.getOpenFileName(self, "Select File to Encrypt")
        if file_path:
            self.file_to_encrypt = Path(file_path)
            self.file_encrypt_label.setText(f"✅ {self.file_to_encrypt.name}")
            self.file_encrypt_label.setStyleSheet("color: #00ff9d;")
    
    def encrypt_file(self):
        """Encrypt the selected file"""
        if not self.recipient_cert:
            QMessageBox.warning(self, "Missing Certificate", 
                                "Please load recipient certificate first")
            return
        
        if not self.file_to_encrypt:
            QMessageBox.warning(self, "Missing File", "Please select file to encrypt")
            return
        
        try:
            self.output.append(f"🔐 Encrypting file: {self.file_to_encrypt.name}...")
            
            vault = HybridCrypto.encrypt_file(self.file_to_encrypt, self.recipient_cert)
            
            vault_name = f"{self.file_to_encrypt.name}.vault"
            
            self.output.append(f"✅ File encrypted successfully!")
            self.output.append(f"   Vault file: {vault_name}")
            self.output.append(f"   Algorithm: {vault['algorithm']}")
            self.output.append(f"   Recipient: {vault['recipient_serial']}")
            self.output.append("")
            
            QMessageBox.information(self, "Success", 
                                    f"File encrypted successfully!\n\n"
                                    f"Vault: {vault_name}")
        except Exception as e:
            self.output.append(f"❌ Error: {str(e)}")
            QMessageBox.critical(self, "Error", f"Failed to encrypt file:\n{str(e)}")
    
    def load_decryptor_identity(self):
        """Load PKCS#12 identity for decryption"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load PKCS#12 Identity", "", "PKCS#12 Files (*.p12)"
        )
        
        if file_path:
            password, ok = QInputDialog.getText(
                self, "Password Required", "Enter PKCS#12 password:",
                QLineEdit.Password
            )
            
            if ok and password:
                try:
                    self.decryptor_key, decryptor_cert, _ = KeystoreManager.import_p12(
                        Path(file_path), password
                    )
                    
                    subject = decryptor_cert.subject.rfc4514_string()
                    self.decryptor_label.setText(f"✅ {subject[:50]}...")
                    self.decryptor_label.setStyleSheet("color: #00ff9d;")
                    self.output.append(f"✅ Decryptor identity loaded: {subject}")
                except Exception as e:
                    QMessageBox.critical(self, "Error", f"Failed to load identity:\n{str(e)}")
    
    def select_vault_file(self):
        """Select vault file to decrypt"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Vault File", "", "Vault Files (*.vault)"
        )
        
        if file_path:
            self.vault_file = Path(file_path)
            self.vault_label.setText(f"✅ {self.vault_file.name}")
            self.vault_label.setStyleSheet("color: #00ff9d;")
    
    def decrypt_file(self):
        """Decrypt vault file"""
        if not self.decryptor_key:
            QMessageBox.warning(self, "Missing Identity", 
                                "Please load PKCS#12 identity first")
            return
        
        if not self.vault_file:
            QMessageBox.warning(self, "Missing Vault", "Please select vault file")
            return
        
        try:
            # Get vault info first
            info = HybridCrypto.get_vault_info(self.vault_file)
            
            self.output.append(f"🔓 Decrypting vault: {self.vault_file.name}...")
            
            # Prompt for output location
            output_path, _ = QFileDialog.getSaveFileName(
                self, "Save Decrypted File",
                info.get('file_name', 'decrypted_file')
            )
            
            if output_path:
                plaintext = HybridCrypto.decrypt_file(
                    self.vault_file,
                    self.decryptor_key,
                    Path(output_path)
                )
                
                self.output.append(f"✅ File decrypted successfully!")
                self.output.append(f"   Output: {output_path}")
                self.output.append(f"   Size: {len(plaintext)} bytes")
                self.output.append("")
                
                QMessageBox.information(self, "Success", 
                                        f"File decrypted successfully!\n\n"
                                        f"Output: {output_path}")
        except Exception as e:
            self.output.append(f"❌ Error: {str(e)}")
            QMessageBox.critical(self, "Error", f"Failed to decrypt file:\n{str(e)}")
