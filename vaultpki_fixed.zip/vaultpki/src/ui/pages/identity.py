"""
VaultPKI - Identity & Certificates Page
CA creation and user enrollment
"""

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                               QPushButton, QLineEdit, QTextEdit, QFileDialog,
                               QMessageBox, QFrame, QGroupBox)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from pathlib import Path

from core.pki import PKIManager
from core.keystore import KeystoreManager


class IdentityPage(QWidget):
    """Identity and certificate management"""
    
    def __init__(self):
        super().__init__()
        self.pki = PKIManager()
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(40, 40, 40, 40)
        layout.setSpacing(20)
        
        # Page title
        title = QLabel("👤 Identity & Certificates")
        title.setFont(QFont("Arial", 28, QFont.Bold))
        title.setStyleSheet("color: #00ff9d;")
        layout.addWidget(title)
        
        subtitle = QLabel("Create Certificate Authority and Enroll Users")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setStyleSheet("color: #7a8ba0; padding-bottom: 20px;")
        layout.addWidget(subtitle)
        
        # CA Section
        ca_group = self._create_ca_section()
        layout.addWidget(ca_group)
        
        # User Enrollment Section
        enroll_group = self._create_enrollment_section()
        layout.addWidget(enroll_group)
        
        # Output area
        self.output = QTextEdit()
        self.output.setReadOnly(True)
        self.output.setMaximumHeight(200)
        self.output.setStyleSheet("""
            QTextEdit {
                background: #0d1117;
                color: #00ff9d;
                border: 1px solid #2a3f5f;
                border-radius: 6px;
                padding: 10px;
                font-family: 'Courier New';
                font-size: 11px;
            }
        """)
        layout.addWidget(self.output)
        
        layout.addStretch()
    
    def _create_ca_section(self):
        """Create CA management section"""
        group = QGroupBox("Certificate Authority")
        group.setStyleSheet("""
            QGroupBox {
                color: #00ff9d;
                border: 2px solid #2a3f5f;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 20px;
                font-size: 14px;
                font-weight: bold;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 15px;
                padding: 0 5px;
            }
        """)
        
        layout = QVBoxLayout()
        
        info = QLabel("Create a local Certificate Authority to issue and sign certificates")
        info.setStyleSheet("color: #7a8ba0; padding: 10px;")
        info.setWordWrap(True)
        layout.addWidget(info)
        
        btn_layout = QHBoxLayout()
        
        create_btn = QPushButton("🔨 Create CA")
        create_btn.clicked.connect(self.create_ca)
        btn_layout.addWidget(create_btn)
        
        load_btn = QPushButton("📂 Load Existing CA")
        load_btn.clicked.connect(self.load_ca)
        btn_layout.addWidget(load_btn)
        
        btn_layout.addStretch()
        
        layout.addLayout(btn_layout)
        group.setLayout(layout)
        
        return group
    
    def _create_enrollment_section(self):
        """Create user enrollment section"""
        group = QGroupBox("User Enrollment")
        group.setStyleSheet("""
            QGroupBox {
                color: #00d4ff;
                border: 2px solid #2a3f5f;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 20px;
                font-size: 14px;
                font-weight: bold;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 15px;
                padding: 0 5px;
            }
        """)
        
        layout = QVBoxLayout()
        
        info = QLabel("Enroll users and export their identity as PKCS#12 (.p12) files")
        info.setStyleSheet("color: #7a8ba0; padding: 10px;")
        info.setWordWrap(True)
        layout.addWidget(info)
        
        # Username input
        input_layout = QHBoxLayout()
        
        username_label = QLabel("Username:")
        username_label.setMinimumWidth(100)
        input_layout.addWidget(username_label)
        
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("e.g., Alice, Bob, Charlie")
        input_layout.addWidget(self.username_input)
        
        layout.addLayout(input_layout)
        
        # Email input
        email_layout = QHBoxLayout()
        
        email_label = QLabel("Email:")
        email_label.setMinimumWidth(100)
        email_layout.addWidget(email_label)
        
        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText("user@example.com (optional)")
        email_layout.addWidget(self.email_input)
        
        layout.addLayout(email_layout)
        
        # Password input
        password_layout = QHBoxLayout()
        
        password_label = QLabel("P12 Password:")
        password_label.setMinimumWidth(100)
        password_layout.addWidget(password_label)
        
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.setPlaceholderText("Password to protect PKCS#12 file")
        password_layout.addWidget(self.password_input)
        
        layout.addLayout(password_layout)
        
        # Buttons
        btn_layout = QHBoxLayout()
        
        enroll_btn = QPushButton("✅ Enroll User")
        enroll_btn.clicked.connect(self.enroll_user)
        btn_layout.addWidget(enroll_btn)
        
        btn_layout.addStretch()
        
        layout.addLayout(btn_layout)
        group.setLayout(layout)
        
        return group
    
    def create_ca(self):
        """Create new Certificate Authority"""
        try:
            self.output.append("🔨 Creating Certificate Authority...")
            ca_cert, ca_key = self.pki.create_ca()
            
            info = self.pki.get_certificate_info(ca_cert)
            
            self.output.append(f"✅ CA Created Successfully!")
            self.output.append(f"   Serial: {info['serial']}")
            self.output.append(f"   Subject: {info['subject']}")
            self.output.append(f"   Valid: {info['not_before']} to {info['not_after']}")
            self.output.append(f"   Files: ca_cert.pem, ca_key.pem")
            self.output.append("")
            
            QMessageBox.information(self, "Success", 
                                    "Certificate Authority created successfully!\n\n"
                                    "Files saved:\n• ca_cert.pem\n• ca_key.pem")
        except Exception as e:
            self.output.append(f"❌ Error: {str(e)}")
            QMessageBox.critical(self, "Error", f"Failed to create CA:\n{str(e)}")
    
    def load_ca(self):
        """Load existing Certificate Authority"""
        try:
            self.output.append("📂 Loading Certificate Authority...")
            ca_cert, ca_key = self.pki.load_ca()
            
            info = self.pki.get_certificate_info(ca_cert)
            
            self.output.append(f"✅ CA Loaded Successfully!")
            self.output.append(f"   Serial: {info['serial']}")
            self.output.append(f"   Subject: {info['subject']}")
            self.output.append("")
            
            QMessageBox.information(self, "Success", "CA loaded successfully!")
        except FileNotFoundError:
            self.output.append("❌ CA files not found. Create CA first.")
            QMessageBox.warning(self, "Not Found", 
                                "CA files not found. Please create CA first.")
        except Exception as e:
            self.output.append(f"❌ Error: {str(e)}")
            QMessageBox.critical(self, "Error", f"Failed to load CA:\n{str(e)}")
    
    def enroll_user(self):
        """Enroll new user"""
        username = self.username_input.text().strip()
        email = self.email_input.text().strip() or None
        password = self.password_input.text()
        
        if not username:
            QMessageBox.warning(self, "Input Required", "Please enter a username")
            return
        
        if not password:
            QMessageBox.warning(self, "Input Required", "Please enter a password for PKCS#12 file")
            return
        
        try:
            self.output.append(f"👤 Enrolling user: {username}...")
            
            # Enroll user
            user_cert, user_key = self.pki.enroll_user(username, email)
            
            # Export as PKCS#12
            output_path, _ = QFileDialog.getSaveFileName(
                self, "Save PKCS#12 Identity", 
                f"{username}.p12",
                "PKCS#12 Files (*.p12)"
            )
            
            if output_path:
                KeystoreManager.export_p12(
                    user_cert, user_key, password, 
                    Path(output_path), username
                )
                
                # Also export certificate only
                cert_path = Path(output_path).with_suffix('.pem')
                KeystoreManager.export_certificate_only(user_cert, cert_path)
                
                info = self.pki.get_certificate_info(user_cert)
                
                self.output.append(f"✅ User Enrolled Successfully!")
                self.output.append(f"   Serial: {info['serial']}")
                self.output.append(f"   Subject: {info['subject']}")
                self.output.append(f"   Identity: {output_path}")
                self.output.append(f"   Certificate: {cert_path}")
                self.output.append("")
                
                QMessageBox.information(self, "Success", 
                                        f"User '{username}' enrolled!\n\n"
                                        f"PKCS#12: {output_path}\n"
                                        f"Certificate: {cert_path}")
                
                # Clear inputs
                self.username_input.clear()
                self.email_input.clear()
                self.password_input.clear()
        except Exception as e:
            self.output.append(f"❌ Error: {str(e)}")
            QMessageBox.critical(self, "Error", f"Failed to enroll user:\n{str(e)}")
