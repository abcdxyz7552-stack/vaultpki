"""
VaultPKI - Audit Logs Page
View system logs and cryptographic operations
"""

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                               QPushButton, QTextEdit, QMessageBox)
from PySide6.QtGui import QFont
from pathlib import Path
import json
from datetime import datetime

from core.crl import CRLManager
from core.replay_guard import ReplayGuard


class LogsPage(QWidget):
    """Audit logs and system monitoring"""
    
    def __init__(self):
        super().__init__()
        self.crl = CRLManager()
        self.replay_guard = ReplayGuard()
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(40, 40, 40, 40)
        layout.setSpacing(20)
        
        # Page title
        title = QLabel("📜 Audit Logs")
        title.setFont(QFont("Arial", 28, QFont.Bold))
        title.setStyleSheet("color: #00ff9d;")
        layout.addWidget(title)
        
        subtitle = QLabel("System Logs & Cryptographic Operations")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setStyleSheet("color: #7a8ba0; padding-bottom: 20px;")
        layout.addWidget(subtitle)
        
        # Buttons
        btn_layout = QHBoxLayout()
        
        refresh_btn = QPushButton("🔄 Refresh Logs")
        refresh_btn.clicked.connect(self.refresh_logs)
        btn_layout.addWidget(refresh_btn)
        
        crl_btn = QPushButton("📋 View CRL")
        crl_btn.clicked.connect(self.view_crl)
        btn_layout.addWidget(crl_btn)
        
        nonces_btn = QPushButton("🔢 View Nonces")
        nonces_btn.clicked.connect(self.view_nonces)
        btn_layout.addWidget(nonces_btn)
        
        clear_btn = QPushButton("🗑️ Clear Old Nonces")
        clear_btn.clicked.connect(self.clear_old_nonces)
        btn_layout.addWidget(clear_btn)
        
        btn_layout.addStretch()
        
        layout.addLayout(btn_layout)
        
        # Log display
        self.log_display = QTextEdit()
        self.log_display.setReadOnly(True)
        self.log_display.setStyleSheet("""
            QTextEdit {
                background: #0d1117;
                color: #00ff9d;
                border: 1px solid #2a3f5f;
                border-radius: 6px;
                padding: 15px;
                font-family: 'Courier New';
                font-size: 11px;
                line-height: 1.5;
            }
        """)
        layout.addWidget(self.log_display)
        
        # Auto-load logs on init
        self.refresh_logs()
    
    def refresh_logs(self):
        """Refresh and display system logs"""
        self.log_display.clear()
        
        self.log_display.append("=" * 80)
        self.log_display.append("VaultPKI - System Audit Log".center(80))
        self.log_display.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}".center(80))
        self.log_display.append("=" * 80)
        self.log_display.append("")
        
        # CA Status
        self.log_display.append("📊 SYSTEM STATUS")
        self.log_display.append("-" * 80)
        
        ca_cert_path = Path.cwd() / "ca_cert.pem"
        if ca_cert_path.exists():
            self.log_display.append("✅ Certificate Authority: ACTIVE")
            self.log_display.append(f"   CA Cert: {ca_cert_path}")
        else:
            self.log_display.append("❌ Certificate Authority: NOT INITIALIZED")
        
        self.log_display.append("")
        
        # CRL Stats
        self.log_display.append("🔒 CERTIFICATE REVOCATION LIST")
        self.log_display.append("-" * 80)
        
        revoked_count = self.crl.get_revoked_count()
        self.log_display.append(f"Total Revoked Certificates: {revoked_count}")
        
        if revoked_count > 0:
            revoked_serials = self.crl.get_all_revoked()
            self.log_display.append(f"Revoked Serials: {', '.join(map(str, revoked_serials[:10]))}")
            if len(revoked_serials) > 10:
                self.log_display.append(f"   ... and {len(revoked_serials) - 10} more")
        
        self.log_display.append("")
        
        # Nonce Database Stats
        self.log_display.append("🔄 REPLAY PROTECTION (NONCE DATABASE)")
        self.log_display.append("-" * 80)
        
        nonce_count = self.replay_guard.get_nonce_count()
        self.log_display.append(f"Total Nonces Stored: {nonce_count}")
        self.log_display.append(f"Database: {self.replay_guard.db_path}")
        
        self.log_display.append("")
        
        # Files in current directory
        self.log_display.append("📁 CRYPTOGRAPHIC FILES")
        self.log_display.append("-" * 80)
        
        file_types = {
            '.pem': 'Certificates',
            '.p12': 'PKCS#12 Identities',
            '.sig': 'Signatures',
            '.vault': 'Encrypted Vaults',
        }
        
        for ext, desc in file_types.items():
            files = list(Path.cwd().glob(f'*{ext}'))
            if files:
                self.log_display.append(f"{desc}: {len(files)} file(s)")
                for f in files[:5]:
                    self.log_display.append(f"   • {f.name}")
                if len(files) > 5:
                    self.log_display.append(f"   ... and {len(files) - 5} more")
        
        self.log_display.append("")
        self.log_display.append("=" * 80)
    
    def view_crl(self):
        """Display CRL contents"""
        revoked_serials = self.crl.get_all_revoked()
        
        if not revoked_serials:
            QMessageBox.information(self, "CRL Empty", "No certificates have been revoked")
            return
        
        crl_text = "Certificate Revocation List\n\n"
        crl_text += f"Total Revoked: {len(revoked_serials)}\n\n"
        crl_text += "Revoked Certificate Serials:\n"
        
        for serial in revoked_serials:
            crl_text += f"  • {serial}\n"
        
        msg = QMessageBox(self)
        msg.setWindowTitle("Certificate Revocation List")
        msg.setText(crl_text)
        msg.setStyleSheet("""
            QMessageBox {
                background: #0a0e1a;
            }
            QLabel {
                color: #e0e0e0;
                font-family: 'Courier New';
            }
        """)
        msg.exec()
    
    def view_nonces(self):
        """Display nonce statistics"""
        nonce_count = self.replay_guard.get_nonce_count()
        
        nonce_text = f"Nonce Database Statistics\n\n"
        nonce_text += f"Total Nonces: {nonce_count}\n"
        nonce_text += f"Database Path: {self.replay_guard.db_path}\n\n"
        nonce_text += "These nonces prevent replay attacks by ensuring\n"
        nonce_text += "each signature can only be used once."
        
        QMessageBox.information(self, "Nonce Database", nonce_text)
    
    def clear_old_nonces(self):
        """Clear old nonces from database"""
        reply = QMessageBox.question(
            self, "Clear Old Nonces",
            "Clear nonces older than 30 days?\n\n"
            "This will free up database space while keeping\n"
            "recent nonces for replay protection.",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            deleted = self.replay_guard.cleanup_old_nonces(30)
            
            self.log_display.append(f"🗑️ Cleaned up {deleted} old nonces")
            self.log_display.append("")
            
            QMessageBox.information(self, "Cleanup Complete", 
                                    f"Removed {deleted} nonces older than 30 days")
            
            self.refresh_logs()
