"""
VaultPKI - Sign / Verify Page
Digital signature operations
"""

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                               QPushButton, QLineEdit, QTextEdit, QFileDialog,
                               QMessageBox, QGroupBox)
from PySide6.QtGui import QFont
from pathlib import Path

from core.pki import PKIManager
from core.keystore import KeystoreManager
from core.signing import SignatureManager
from core.crl import CRLManager
from core.replay_guard import ReplayGuard


class SignVerifyPage(QWidget):
    """Digital signature creation and verification"""
    
    def __init__(self):
        super().__init__()
        self.pki = PKIManager()
        self.crl = CRLManager()
        self.replay_guard = ReplayGuard()
        
        self.signer_cert = None
        self.signer_key = None
        self.file_to_sign = None
        self.file_to_verify = None
        self.signature_file = None
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(40, 40, 40, 40)
        layout.setSpacing(20)
        
        # Page title
        title = QLabel("✍️ Sign / Verify")
        title.setFont(QFont("Arial", 28, QFont.Bold))
        title.setStyleSheet("color: #00ff9d;")
        layout.addWidget(title)
        
        subtitle = QLabel("Create and Verify Digital Signatures")
        subtitle.setFont(QFont("Arial", 12))
        subtitle.setStyleSheet("color: #7a8ba0; padding-bottom: 20px;")
        layout.addWidget(subtitle)
        
        # Sign section
        sign_group = self._create_sign_section()
        layout.addWidget(sign_group)
        
        # Verify section
        verify_group = self._create_verify_section()
        layout.addWidget(verify_group)
        
        # Output
        self.output = QTextEdit()
        self.output.setReadOnly(True)
        self.output.setMaximumHeight(250)
        self.output.setStyleSheet("""
            QTextEdit {
                background: #0d1117;
                color: #00ff9d;
                border: 1px solid #2a3f5f;
                border-radius: 6px;
                padding: 10px;
                font-family: 'Courier New';
                font-size: 11px;
            }
        """)
        layout.addWidget(self.output)
        
        layout.addStretch()
    
    def _create_sign_section(self):
        """Create file signing section"""
        group = QGroupBox("Sign File")
        group.setStyleSheet("""
            QGroupBox {
                color: #00ff9d;
                border: 2px solid #2a3f5f;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 20px;
                font-size: 14px;
                font-weight: bold;
            }
        """)
        
        layout = QVBoxLayout()
        
        # Load identity
        identity_layout = QHBoxLayout()
        self.identity_label = QLabel("No identity loaded")
        self.identity_label.setStyleSheet("color: #7a8ba0;")
        identity_layout.addWidget(self.identity_label)
        
        load_identity_btn = QPushButton("📂 Load PKCS#12 Identity")
        load_identity_btn.clicked.connect(self.load_identity)
        identity_layout.addWidget(load_identity_btn)
        
        layout.addLayout(identity_layout)
        
        # Select file
        file_layout = QHBoxLayout()
        self.file_sign_label = QLabel("No file selected")
        self.file_sign_label.setStyleSheet("color: #7a8ba0;")
        file_layout.addWidget(self.file_sign_label)
        
        select_file_btn = QPushButton("📄 Select File to Sign")
        select_file_btn.clicked.connect(self.select_file_to_sign)
        file_layout.addWidget(select_file_btn)
        
        layout.addLayout(file_layout)
        
        # Sign button
        sign_btn = QPushButton("✍️ Sign File")
        sign_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #00ff9d, stop:1 #00d4ff);
                color: #0a0e1a;
                font-weight: bold;
                padding: 12px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #00d4ff, stop:1 #00ff9d);
            }
        """)
        sign_btn.clicked.connect(self.sign_file)
        layout.addWidget(sign_btn)
        
        group.setLayout(layout)
        return group
    
    def _create_verify_section(self):
        """Create signature verification section"""
        group = QGroupBox("Verify Signature")
        group.setStyleSheet("""
            QGroupBox {
                color: #00d4ff;
                border: 2px solid #2a3f5f;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 20px;
                font-size: 14px;
                font-weight: bold;
            }
        """)
        
        layout = QVBoxLayout()
        
        # Select signed file
        file_layout = QHBoxLayout()
        self.file_verify_label = QLabel("No file selected")
        self.file_verify_label.setStyleSheet("color: #7a8ba0;")
        file_layout.addWidget(self.file_verify_label)
        
        select_file_btn = QPushButton("📄 Select Signed File")
        select_file_btn.clicked.connect(self.select_file_to_verify)
        file_layout.addWidget(select_file_btn)
        
        layout.addLayout(file_layout)
        
        # Select signature
        sig_layout = QHBoxLayout()
        self.sig_label = QLabel("No signature selected")
        self.sig_label.setStyleSheet("color: #7a8ba0;")
        sig_layout.addWidget(self.sig_label)
        
        select_sig_btn = QPushButton("📋 Select Signature File")
        select_sig_btn.clicked.connect(self.select_signature_file)
        sig_layout.addWidget(select_sig_btn)
        
        layout.addLayout(sig_layout)
        
        # Verify button
        verify_btn = QPushButton("🔍 Verify Signature")
        verify_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #00d4ff, stop:1 #9d00ff);
                color: #0a0e1a;
                font-weight: bold;
                padding: 12px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #9d00ff, stop:1 #00d4ff);
            }
        """)
        verify_btn.clicked.connect(self.verify_signature)
        layout.addWidget(verify_btn)
        
        group.setLayout(layout)
        return group
    
    def load_identity(self):
        """Load PKCS#12 identity for signing"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load PKCS#12 Identity", "", "PKCS#12 Files (*.p12)"
        )
        
        if file_path:
            password, ok = self._get_password("Enter PKCS#12 password:")
            if ok and password:
                try:
                    self.signer_key, self.signer_cert, _ = KeystoreManager.import_p12(
                        Path(file_path), password
                    )
                    
                    subject = self.signer_cert.subject.rfc4514_string()
                    self.identity_label.setText(f"✅ Loaded: {subject[:50]}...")
                    self.identity_label.setStyleSheet("color: #00ff9d;")
                    self.output.append(f"✅ Identity loaded: {subject}")
                except Exception as e:
                    QMessageBox.critical(self, "Error", f"Failed to load identity:\n{str(e)}")
    
    def select_file_to_sign(self):
        """Select file to sign"""
        file_path, _ = QFileDialog.getOpenFileName(self, "Select File to Sign")
        if file_path:
            self.file_to_sign = Path(file_path)
            self.file_sign_label.setText(f"✅ {self.file_to_sign.name}")
            self.file_sign_label.setStyleSheet("color: #00ff9d;")
    
    def select_file_to_verify(self):
        """Select file to verify"""
        file_path, _ = QFileDialog.getOpenFileName(self, "Select Signed File")
        if file_path:
            self.file_to_verify = Path(file_path)
            self.file_verify_label.setText(f"✅ {self.file_to_verify.name}")
            self.file_verify_label.setStyleSheet("color: #00ff9d;")
    
    def select_signature_file(self):
        """Select signature file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Signature File", "", "Signature Files (*.sig)"
        )
        if file_path:
            self.signature_file = Path(file_path)
            self.sig_label.setText(f"✅ {self.signature_file.name}")
            self.sig_label.setStyleSheet("color: #00ff9d;")
    
    def sign_file(self):
        """Sign the selected file"""
        if not self.signer_cert or not self.signer_key:
            QMessageBox.warning(self, "Missing Identity", "Please load PKCS#12 identity first")
            return
        
        if not self.file_to_sign:
            QMessageBox.warning(self, "Missing File", "Please select file to sign")
            return
        
        try:
            # Load CA for signature manager
            ca_cert, _ = self.pki.load_ca()
            sig_manager = SignatureManager(ca_cert, self.crl, self.replay_guard)
            
            self.output.append(f"✍️ Signing file: {self.file_to_sign.name}...")
            
            metadata = sig_manager.sign_file(
                self.file_to_sign,
                self.signer_cert,
                self.signer_key
            )
            
            self.output.append(f"✅ Signature created successfully!")
            self.output.append(f"   Signature file: {self.file_to_sign.name}.sig")
            self.output.append(f"   Algorithm: {metadata['algorithm']}")
            self.output.append(f"   Timestamp: {metadata['timestamp']}")
            self.output.append(f"   Nonce: {metadata['nonce'][:16]}...")
            self.output.append("")
            
            QMessageBox.information(self, "Success", 
                                    f"File signed successfully!\n\n"
                                    f"Signature: {self.file_to_sign.name}.sig")
        except Exception as e:
            self.output.append(f"❌ Error: {str(e)}")
            QMessageBox.critical(self, "Error", f"Failed to sign file:\n{str(e)}")
    
    def verify_signature(self):
        """Verify signature"""
        if not self.file_to_verify or not self.signature_file:
            QMessageBox.warning(self, "Missing Files", 
                                "Please select both file and signature")
            return
        
        try:
            ca_cert, _ = self.pki.load_ca()
            sig_manager = SignatureManager(ca_cert, self.crl, self.replay_guard)
            
            self.output.append(f"🔍 Verifying signature for: {self.file_to_verify.name}...")
            
            results = sig_manager.verify_signature(self.file_to_verify, self.signature_file)
            
            if results['valid']:
                self.output.append("✅ SIGNATURE VALID!")
                self.output.append(f"   ✓ Signature cryptographically valid")
                self.output.append(f"   ✓ File integrity verified")
                self.output.append(f"   ✓ Certificate trusted and valid")
                self.output.append(f"   ✓ Certificate not revoked")
                self.output.append(f"   ✓ No replay detected")
                self.output.append("")
                
                QMessageBox.information(self, "✅ Valid Signature", 
                                        "Signature verification PASSED!\n\n"
                                        "All security checks successful.")
            else:
                self.output.append("❌ SIGNATURE INVALID!")
                for error in results['errors']:
                    self.output.append(f"   ✗ {error}")
                self.output.append("")
                
                QMessageBox.warning(self, "❌ Invalid Signature", 
                                    "Signature verification FAILED!\n\n" + 
                                    "\n".join(results['errors']))
        except Exception as e:
            self.output.append(f"❌ Error: {str(e)}")
            QMessageBox.critical(self, "Error", f"Verification failed:\n{str(e)}")
    
    def _get_password(self, prompt):
        """Simple password dialog"""
        from PySide6.QtWidgets import QInputDialog
        return QInputDialog.getText(self, "Password Required", prompt, 
                                     QLineEdit.Password)
